'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { Calculator, TrendingUp, Loader2, BarChart3 } from 'lucide-react'
import { ANALYTICS_TYPES } from '@/utils/scoreFormulas'
import { AnalyticsCalculator } from '@/components/analytics-calculator'
import { AnalyticsDashboard } from '@/components/analytics-dashboard'


export default function AnalyticsPage() {
  const [selectedAnalytic, setSelectedAnalytic] = useState<string>('')
  const [analyticsData, setAnalyticsData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showDashboard, setShowDashboard] = useState(true)

  // Auto-load data when analytics type is selected
  useEffect(() => {
    if (selectedAnalytic && !showDashboard) {
      loadAnalyticsData(selectedAnalytic)
    }
  }, [selectedAnalytic, showDashboard])

  const loadAnalyticsData = async (businessType: string) => {
    setIsLoading(true)
    setError(null)
    
    try {
      const response = await fetch(`/api/analytics?businessType=${businessType}`)
      const result = await response.json()
      
      if (result.success) {
        setAnalyticsData(result.data)
      } else {
        setError(result.error || 'Failed to load analytics data')
      }
    } catch (err) {
      setError('Error loading analytics data')
      console.error('Error loading analytics data:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const selectedAnalyticData = ANALYTICS_TYPES.find(type => type.id === selectedAnalytic)

  const handleSelectMetric = (metricId: string) => {
    setSelectedAnalytic(metricId)
    setShowDashboard(false)
  }

  return (
    <div className="container mx-auto px-4 py-6 md:py-8">
      <div className="mb-6 md:mb-8">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-2">Analytics Dashboard</h1>
            <p className="text-base md:text-lg text-muted-foreground">
              {showDashboard 
                ? 'Overview of all business metrics calculated from your data'
                : 'Calculate business scores using your metrics data. Select an analytics type and upload your CSV file.'
              }
            </p>
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            <Button 
              variant={showDashboard ? "default" : "outline"}
              onClick={() => setShowDashboard(true)}
              className="flex items-center gap-2 flex-1 md:flex-none"
              size="sm"
            >
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </Button>
            <Button 
              variant={!showDashboard ? "default" : "outline"}
              onClick={() => setShowDashboard(false)}
              className="flex items-center gap-2 flex-1 md:flex-none"
              size="sm"
            >
              <Calculator className="h-4 w-4" />
              <span className="hidden sm:inline">Detailed Analytics</span>
            </Button>
          </div>
        </div>
      </div>

      {showDashboard ? (
        <AnalyticsDashboard onSelectMetric={handleSelectMetric} />
      ) : (
        <div className="grid gap-4 md:gap-6 lg:grid-cols-3">
          {/* Analytics Selection */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Select Analytics Type
                </CardTitle>
                <CardDescription>
                  Choose the type of business score you want to calculate
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Select value={selectedAnalytic} onValueChange={setSelectedAnalytic}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select an analytics type..." />
                  </SelectTrigger>
                  <SelectContent>
                    {ANALYTICS_TYPES.map((type) => (
                      <SelectItem key={type.id} value={type.id}>
                        {type.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {selectedAnalyticData && (
                  <div className="mt-4 space-y-4">
                    <div className="p-4 bg-muted rounded-lg">
                      <h4 className="font-semibold mb-2">Formula:</h4>
                      <code className="text-sm bg-background px-2 py-1 rounded block mb-3">
                        {selectedAnalyticData.formula}
                      </code>
                      <div className="text-sm text-muted-foreground space-y-2">
                        <div>
                          <span className="font-medium">Variables:</span>
                          <p className="mt-1">{selectedAnalyticData.variables}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                      <h4 className="font-semibold mb-2 text-blue-900 dark:text-blue-100">Score Range:</h4>
                      <p className="text-sm text-blue-800 dark:text-blue-200 mb-3">
                        {(selectedAnalyticData as any).scoreRange}
                      </p>
                      <p className="text-sm text-blue-800 dark:text-blue-200">
                        {(selectedAnalyticData as any).interpretation}
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Data Status */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Data Status
                </CardTitle>
                <CardDescription>
                  Preloaded analytics data from your metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex items-center justify-center gap-2 py-4">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Loading analytics data...</span>
                  </div>
                ) : error ? (
                  <div className="text-center py-4">
                    <p className="text-red-600 font-medium">Error</p>
                    <p className="text-sm text-muted-foreground">{error}</p>
                  </div>
                ) : analyticsData.length > 0 ? (
                  <div className="text-center py-4">
                    <p className="font-medium text-green-600">Data Loaded</p>
                    <p className="text-sm text-muted-foreground">
                      {analyticsData.length} rows ready for analysis
                    </p>
                  </div>
                ) : selectedAnalytic ? (
                  <div className="text-center py-4">
                    <p className="text-muted-foreground">
                      No data available for this analytics type
                    </p>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-muted-foreground">
                      Select an analytics type to load data
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Analytics Results */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Analytics Results
                </CardTitle>
                <CardDescription>
                  {selectedAnalyticData ? selectedAnalyticData.description : 'Select an analytics type to see results'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {selectedAnalytic && analyticsData.length > 0 && !isLoading ? (
                  <AnalyticsCalculator
                    analyticType={selectedAnalytic}
                    data={analyticsData}
                    analyticData={selectedAnalyticData!}
                  />
                ) : (
                  <div className="flex items-center justify-center h-64 text-muted-foreground">
                    <div className="text-center">
                      {isLoading ? (
                        <>
                          <Loader2 className="h-12 w-12 mx-auto mb-4 animate-spin" />
                          <p className="text-lg font-medium">Loading Analytics Data</p>
                          <p className="text-sm">Please wait...</p>
                        </>
                      ) : (
                        <>
                          <Calculator className="h-12 w-12 mx-auto mb-4 opacity-50" />
                          <p className="text-lg font-medium">Ready to Calculate</p>
                          <p className="text-sm">
                            {!selectedAnalytic ? 'Select an analytics type to begin' : error ? 'Error loading data' : 'No data available'}
                          </p>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}
