#!/usr/bin/env ts-node

import { seedAnalyticsData } from '../src/lib/seed-analytics'

async function main() {
  try {
    await seedAnalyticsData()
    console.log('✅ Analytics data seeding completed successfully!')
    process.exit(0)
  } catch (error) {
    console.error('❌ Error seeding analytics data:', error)
    process.exit(1)
  }
}

main()
