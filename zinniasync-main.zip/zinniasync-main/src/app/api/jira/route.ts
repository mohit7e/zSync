// app/api/jira/route.ts
import { NextRequest, NextResponse } from 'next/server';
import JiraApiService from '@/lib/jira-api';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Get query parameters
    const projectKey = searchParams.get('project');
    const statusCategory = searchParams.get('status');
    const maxResults = parseInt(searchParams.get('limit') || '1000'); // Increased default limit
    const jql = searchParams.get('jql');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const fetchAll = searchParams.get('fetchAll') === 'true';

    // Initialize Jira API service
    const jiraService = new JiraApiService();

    let tasks;

    // Handle different query types
    if (fetchAll) {
      // Fetch all data using pagination
      tasks = await jiraService.getAllTasks(
        projectKey || undefined,
        statusCategory || undefined,
        jql || undefined
      );
    } else if (jql) {
      // Custom JQL query
      tasks = await jiraService.getTasksByJQL(jql);
    } else if (startDate && endDate) {
      // Date range query
      tasks = await jiraService.getTasksByDateRange(startDate, endDate, projectKey || undefined);
    } else {
      // Standard filtered query
      tasks = await jiraService.getFilteredTasks(
        projectKey || undefined,
        statusCategory || undefined,
        maxResults
      );
    }

    return NextResponse.json({
      success: true,
      data: tasks,
      count: tasks.length
    });

  } catch (error: any) {
    console.error('Jira API Error:', error);

    // Handle different error types
    if (error.message.includes('credentials not provided')) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'Jira credentials not configured. Please set JIRA_EMAIL and JIRA_API_TOKEN environment variables.' 
        },
        { status: 401 }
      );
    }

    if (error.message.includes('Jira API Error: 401')) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'Invalid Jira credentials. Please check your email and API token.' 
        },
        { status: 401 }
      );
    }

    if (error.message.includes('Jira API Error: 403')) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'Insufficient permissions to access Jira data.' 
        },
        { status: 403 }
      );
    }

    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to fetch Jira data',
        details: error.message 
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { jql, maxResults = 100 } = body;

    if (!jql) {
      return NextResponse.json(
        { success: false, error: 'JQL query is required' },
        { status: 400 }
      );
    }

    const jiraService = new JiraApiService();
    const tasks = await jiraService.getTasksByJQL(jql);

    return NextResponse.json({
      success: true,
      data: tasks,
      count: tasks.length
    });

  } catch (error: any) {
    console.error('Jira API Error:', error);
    
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to execute JQL query',
        details: error.message 
      },
      { status: 500 }
    );
  }
}
