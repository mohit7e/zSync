import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    // Get total metrics count
    const totalMetrics = await prisma.metric.count()

    // Get metrics by tag
    const metricsByTag = await prisma.metric.groupBy({
      by: ['tag'],
      _count: {
        id: true
      }
    })

    // Get metrics by category
    const metricsByCategory = await prisma.metric.groupBy({
      by: ['categoryId'],
      _count: {
        id: true
      }
    })

    // Get categories for mapping
    const categories = await prisma.metricCategory.findMany()
    const categoryMap = Object.fromEntries(
      categories.map((cat: any) => [cat.id, cat.name])
    )

    // Calculate on-time delivery rate
    const onTimeCount = metricsByTag.find((m: any) => m.tag === 'on-time')?._count.id || 0
    const completedCount = metricsByTag
      .filter((m: any) => ['on-time', 'delayed'].includes(m.tag))
      .reduce((sum: number, m: any) => sum + m._count.id, 0)
    
    const onTimeRate = completedCount > 0 
      ? Math.round((onTimeCount / completedCount) * 100) 
      : 0

    // Format metrics by category with names
    const formattedMetricsByCategory = metricsByCategory.map((m: any) => ({
      category: categoryMap[m.categoryId] || 'Unknown',
      categoryId: m.categoryId,
      count: m._count.id
    }))

    // Get recent metrics
    const recentMetrics = await prisma.metric.findMany({
      take: 10,
      orderBy: {
        createdAt: 'desc'
      },
      include: {
        category: true
      }
    })

    return NextResponse.json({
      summary: {
        totalMetrics,
        onTimeRate,
        targetOnTimeRate: 90,
        metricsByTag: Object.fromEntries(
          metricsByTag.map((m: any) => [m.tag, m._count.id])
        ),
        metricsByCategory: formattedMetricsByCategory
      },
      recentMetrics
    })
  } catch (error) {
    console.error('Summary fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch summary' },
      { status: 500 }
    )
  }
} 