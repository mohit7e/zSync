import { NextRequest, NextResponse } from 'next/server'
import { getAnalyticsData } from '@/lib/seed-analytics'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const businessType = searchParams.get('businessType')
    
    if (!businessType) {
      return NextResponse.json(
        { error: 'businessType parameter is required' },
        { status: 400 }
      )
    }
    
    const data = await getAnalyticsData(businessType)
    
    return NextResponse.json({
      success: true,
      businessType,
      data,
      count: data.length
    })
  } catch (error) {
    console.error('Error fetching analytics data:', error)
    return NextResponse.json(
      { error: 'Failed to fetch analytics data' },
      { status: 500 }
    )
  }
}
