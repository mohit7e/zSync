import { PrismaClient } from '@prisma/client'
import { seedAnalyticsData } from '../src/lib/seed-analytics'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Starting database seeding...')
  
  // Create metric categories
  const categories = [
    { name: 'Engineering', description: 'Engineering delivery and technical metrics' },
    { name: 'Release', description: 'Release velocity and deployment metrics' },
    { name: 'Production', description: 'Production quality and incident metrics' },
    { name: 'TPA', description: 'Third-party application operational metrics' },
    { name: 'Call Center', description: 'Call center service and efficiency metrics' },
    { name: 'Cross-Functional', description: 'Cross-functional program and project metrics' },
    { name: 'Sales', description: 'Sales pipeline and conversion metrics' },
    { name: 'Marketing', description: 'Marketing campaign and delivery metrics' },
  ]

  // Clear existing data
  await prisma.metric.deleteMany({})
  await prisma.metricCategory.deleteMany({})
  console.log('🧹 Cleared existing data')

  // Create categories
  const createdCategories: { [key: string]: any } = {}
  for (const category of categories) {
    const created = await prisma.metricCategory.create({ data: category })
    createdCategories[category.name] = created
  }
  console.log('✅ Metric categories seeded successfully')

  // Helper function to generate dates
  const getRandomDate = (daysAgo: number, variance: number = 5) => {
    const baseDate = new Date()
    baseDate.setDate(baseDate.getDate() - daysAgo)
    const randomOffset = Math.floor(Math.random() * variance * 2) - variance
    baseDate.setDate(baseDate.getDate() + randomOffset)
    return baseDate
  }

  // 1. ENGINEERING DELIVERY METRICS
  const engineeringMetrics = [
    {
      source: 'JIRA',
      metricType: 'Feature Delivery',
      taskId: 'ENG-001',
      description: 'User authentication system',
      plannedDate: getRandomDate(30),
      actualDate: getRandomDate(29),
      status: 'Completed',
      tag: 'on-time',
      categoryId: createdCategories['Engineering'].id,
      value: 85,
      unit: 'completion %'
    },
    {
      source: 'JIRA',
      metricType: 'Feature Delivery',
      taskId: 'ENG-002',
      description: 'Payment gateway integration',
      plannedDate: getRandomDate(25),
      actualDate: getRandomDate(22),
      status: 'Completed',
      tag: 'delayed',
      categoryId: createdCategories['Engineering'].id,
      value: 78,
      unit: 'completion %'
    },
    {
      source: 'JIRA',
      metricType: 'Feature Delivery',
      taskId: 'ENG-003',
      description: 'Mobile app optimization',
      plannedDate: getRandomDate(20),
      actualDate: getRandomDate(18),
      status: 'Completed',
      tag: 'on-time',
      categoryId: createdCategories['Engineering'].id,
      value: 92,
      unit: 'completion %'
    },
    {
      source: 'JIRA',
      metricType: 'Feature Delivery',
      taskId: 'ENG-004',
      description: 'API documentation update',
      plannedDate: getRandomDate(15),
      actualDate: null,
      status: 'In Progress',
      tag: 'in-progress',
      categoryId: createdCategories['Engineering'].id,
      value: 65,
      unit: 'completion %'
    },
    {
      source: 'JIRA',
      metricType: 'Feature Delivery',
      taskId: 'ENG-005',
      description: 'Database migration',
      plannedDate: getRandomDate(10),
      actualDate: getRandomDate(12),
      status: 'Completed',
      tag: 'delayed',
      categoryId: createdCategories['Engineering'].id,
      value: 88,
      unit: 'completion %'
    }
  ]

  // 2. RELEASE VELOCITY METRICS
  const releaseMetrics = [
    {
      source: 'Jenkins',
      metricType: 'Release Deployment',
      taskId: 'REL-001',
      description: 'Q4 2024 Release v2.1.0',
      plannedDate: getRandomDate(35),
      actualDate: getRandomDate(34),
      status: 'Completed',
      tag: 'on-time',
      categoryId: createdCategories['Release'].id,
      value: 95,
      unit: 'velocity score'
    },
    {
      source: 'Jenkins',
      metricType: 'Release Deployment',
      taskId: 'REL-002',
      description: 'Hotfix Release v2.1.1',
      plannedDate: getRandomDate(28),
      actualDate: getRandomDate(26),
      status: 'Completed',
      tag: 'on-time',
      categoryId: createdCategories['Release'].id,
      value: 87,
      unit: 'velocity score'
    },
    {
      source: 'Jenkins',
      metricType: 'Release Deployment',
      taskId: 'REL-003',
      description: 'Feature Release v2.2.0',
      plannedDate: getRandomDate(21),
      actualDate: getRandomDate(24),
      status: 'Completed',
      tag: 'delayed',
      categoryId: createdCategories['Release'].id,
      value: 72,
      unit: 'velocity score'
    },
    {
      source: 'Jenkins',
      metricType: 'Release Deployment',
      taskId: 'REL-004',
      description: 'Security Patch v2.2.1',
      plannedDate: getRandomDate(14),
      actualDate: null,
      status: 'In Progress',
      tag: 'in-progress',
      categoryId: createdCategories['Release'].id,
      value: 45,
      unit: 'velocity score'
    }
  ]

  // 3. PRODUCTION QUALITY METRICS
  const productionMetrics = [
    {
      source: 'Monitoring',
      metricType: 'Incident Response',
      taskId: 'PROD-001',
      description: 'Database connection timeout',
      plannedDate: getRandomDate(32),
      actualDate: getRandomDate(32),
      status: 'Resolved',
      tag: 'on-time',
      categoryId: createdCategories['Production'].id,
      value: 94,
      unit: 'quality score'
    },
    {
      source: 'Monitoring',
      metricType: 'Incident Response',
      taskId: 'PROD-002',
      description: 'API rate limiting issue',
      plannedDate: getRandomDate(27),
      actualDate: getRandomDate(28),
      status: 'Resolved',
      tag: 'delayed',
      categoryId: createdCategories['Production'].id,
      value: 81,
      unit: 'quality score'
    },
    {
      source: 'Monitoring',
      metricType: 'Incident Response',
      taskId: 'PROD-003',
      description: 'Memory leak in payment service',
      plannedDate: getRandomDate(19),
      actualDate: getRandomDate(18),
      status: 'Resolved',
      tag: 'on-time',
      categoryId: createdCategories['Production'].id,
      value: 89,
      unit: 'quality score'
    }
  ]

  // 4. TPA OPERATIONAL EFFICIENCY METRICS
  const tpaMetrics = [
    {
      source: 'TPA System',
      metricType: 'Operational Efficiency',
      taskId: 'TPA-001',
      description: 'Stripe payment processing',
      plannedDate: getRandomDate(30),
      actualDate: getRandomDate(29),
      status: 'Operational',
      tag: 'on-time',
      categoryId: createdCategories['TPA'].id,
      value: 96,
      unit: 'efficiency %'
    },
    {
      source: 'TPA System',
      metricType: 'Operational Efficiency',
      taskId: 'TPA-002',
      description: 'AWS S3 file storage',
      plannedDate: getRandomDate(25),
      actualDate: getRandomDate(26),
      status: 'Operational',
      tag: 'delayed',
      categoryId: createdCategories['TPA'].id,
      value: 84,
      unit: 'efficiency %'
    },
    {
      source: 'TPA System',
      metricType: 'Operational Efficiency',
      taskId: 'TPA-003',
      description: 'SendGrid email service',
      plannedDate: getRandomDate(20),
      actualDate: getRandomDate(19),
      status: 'Operational',
      tag: 'on-time',
      categoryId: createdCategories['TPA'].id,
      value: 91,
      unit: 'efficiency %'
    }
  ]

  // 5. CALL CENTER SERVICE LEVEL METRICS
  const callCenterMetrics = [
    {
      source: 'Call Center System',
      metricType: 'Service Level',
      taskId: 'CC-001',
      description: 'Customer support Q4 targets',
      plannedDate: getRandomDate(35),
      actualDate: getRandomDate(34),
      status: 'Achieved',
      tag: 'on-time',
      categoryId: createdCategories['Call Center'].id,
      value: 87,
      unit: 'service level %'
    },
    {
      source: 'Call Center System',
      metricType: 'Service Level',
      taskId: 'CC-002',
      description: 'Technical support response time',
      plannedDate: getRandomDate(28),
      actualDate: getRandomDate(30),
      status: 'Achieved',
      tag: 'delayed',
      categoryId: createdCategories['Call Center'].id,
      value: 79,
      unit: 'service level %'
    },
    {
      source: 'Call Center System',
      metricType: 'Service Level',
      taskId: 'CC-003',
      description: 'First call resolution rate',
      plannedDate: getRandomDate(21),
      actualDate: getRandomDate(20),
      status: 'Achieved',
      tag: 'on-time',
      categoryId: createdCategories['Call Center'].id,
      value: 93,
      unit: 'service level %'
    }
  ]

  // 6. CROSS-FUNCTIONAL PROGRAM DELIVERY METRICS
  const crossFunctionalMetrics = [
    {
      source: 'Project Management',
      metricType: 'Program Delivery',
      taskId: 'CF-001',
      description: 'Customer onboarding improvement',
      plannedDate: getRandomDate(40),
      actualDate: getRandomDate(38),
      status: 'Completed',
      tag: 'on-time',
      categoryId: createdCategories['Cross-Functional'].id,
      value: 92,
      unit: 'delivery score'
    },
    {
      source: 'Project Management',
      metricType: 'Program Delivery',
      taskId: 'CF-002',
      description: 'Security compliance initiative',
      plannedDate: getRandomDate(33),
      actualDate: getRandomDate(36),
      status: 'Completed',
      tag: 'delayed',
      categoryId: createdCategories['Cross-Functional'].id,
      value: 76,
      unit: 'delivery score'
    },
    {
      source: 'Project Management',
      metricType: 'Program Delivery',
      taskId: 'CF-003',
      description: 'Mobile app redesign project',
      plannedDate: getRandomDate(26),
      actualDate: getRandomDate(24),
      status: 'Completed',
      tag: 'on-time',
      categoryId: createdCategories['Cross-Functional'].id,
      value: 88,
      unit: 'delivery score'
    }
  ]

  // 7. SALES PIPELINE CONVERSION METRICS
  const salesMetrics = [
    {
      source: 'CRM',
      metricType: 'Pipeline Conversion',
      taskId: 'SALES-001',
      description: 'Enterprise client acquisition Q4',
      plannedDate: getRandomDate(45),
      actualDate: getRandomDate(43),
      status: 'Closed Won',
      tag: 'on-time',
      categoryId: createdCategories['Sales'].id,
      value: 89,
      unit: 'conversion %'
    },
    {
      source: 'CRM',
      metricType: 'Pipeline Conversion',
      taskId: 'SALES-002',
      description: 'SMB market expansion',
      plannedDate: getRandomDate(38),
      actualDate: getRandomDate(41),
      status: 'Closed Won',
      tag: 'delayed',
      categoryId: createdCategories['Sales'].id,
      value: 73,
      unit: 'conversion %'
    },
    {
      source: 'CRM',
      metricType: 'Pipeline Conversion',
      taskId: 'SALES-003',
      description: 'Product upsell campaign',
      plannedDate: getRandomDate(31),
      actualDate: getRandomDate(29),
      status: 'Closed Won',
      tag: 'on-time',
      categoryId: createdCategories['Sales'].id,
      value: 95,
      unit: 'conversion %'
    },
    {
      source: 'CRM',
      metricType: 'Pipeline Conversion',
      taskId: 'SALES-004',
      description: 'International market entry',
      plannedDate: getRandomDate(24),
      actualDate: null,
      status: 'In Progress',
      tag: 'in-progress',
      categoryId: createdCategories['Sales'].id,
      value: 67,
      unit: 'conversion %'
    }
  ]

  // 8. MARKETING CAMPAIGN EXECUTION METRICS
  const marketingMetrics = [
    {
      source: 'Marketing Automation',
      metricType: 'Campaign Execution',
      taskId: 'MKT-001',
      description: 'Q4 Product launch campaign',
      plannedDate: getRandomDate(42),
      actualDate: getRandomDate(41),
      status: 'Completed',
      tag: 'on-time',
      categoryId: createdCategories['Marketing'].id,
      value: 91,
      unit: 'execution score'
    },
    {
      source: 'Marketing Automation',
      metricType: 'Campaign Execution',
      taskId: 'MKT-002',
      description: 'Holiday season promotion',
      plannedDate: getRandomDate(35),
      actualDate: getRandomDate(38),
      status: 'Completed',
      tag: 'delayed',
      categoryId: createdCategories['Marketing'].id,
      value: 78,
      unit: 'execution score'
    },
    {
      source: 'Marketing Automation',
      metricType: 'Campaign Execution',
      taskId: 'MKT-003',
      description: 'Content marketing initiative',
      plannedDate: getRandomDate(28),
      actualDate: getRandomDate(26),
      status: 'Completed',
      tag: 'on-time',
      categoryId: createdCategories['Marketing'].id,
      value: 86,
      unit: 'execution score'
    },
    {
      source: 'Marketing Automation',
      metricType: 'Campaign Execution',
      taskId: 'MKT-004',
      description: 'Social media engagement boost',
      plannedDate: getRandomDate(21),
      actualDate: null,
      status: 'In Progress',
      tag: 'in-progress',
      categoryId: createdCategories['Marketing'].id,
      value: 72,
      unit: 'execution score'
    }
  ]

  // Combine all metrics
  const allMetrics = [
    ...engineeringMetrics,
    ...releaseMetrics,
    ...productionMetrics,
    ...tpaMetrics,
    ...callCenterMetrics,
    ...crossFunctionalMetrics,
    ...salesMetrics,
    ...marketingMetrics
  ]

  // Create all metrics
  for (const metric of allMetrics) {
    await prisma.metric.create({ data: metric })
  }

  console.log('✅ Sample metrics created successfully')
  console.log(`📊 Created ${allMetrics.length} metrics across ${categories.length} categories`)
  console.log('🎯 Analytics dashboard will now show comprehensive data!')

  // Seed analytics data
  try {
    await seedAnalyticsData()
    console.log('✅ Analytics data seeded successfully')
  } catch (error) {
    console.error('❌ Error seeding analytics data:', error)
  }

  console.log('✅ All seeding completed successfully!')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  }) 