'use client'

import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { format } from 'date-fns'
import { 
  BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, 
  Tooltip, Legend, ResponsiveContainer 
} from 'recharts'
import { Download, TrendingUp, Clock, AlertTriangle, CheckCircle, ExternalLink, RefreshCw } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { getTagColor, formatDateForDisplay } from '@/lib/tagging'
import { toast } from 'sonner'


const TAG_COLORS = {
  'on-time': '#10b981',
  'delayed': '#ef4444',
  'incomplete': '#f97316',
  'in-progress': '#3b82f6'
}

export default function DashboardPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('')
  const [selectedTag, setSelectedTag] = useState<string>('')
  const [dateRange, setDateRange] = useState({
    start: '',
    end: ''
  })
  const [currentPage, setCurrentPage] = useState(1)
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>([])
  const [useJiraData, setUseJiraData] = useState(true)
  const [jiraRefreshing, setJiraRefreshing] = useState(false)
  const [fetchAllJiraData, setFetchAllJiraData] = useState(false)
  const queryClient = useQueryClient()

  // Fetch summary data
  const { data: summaryData, isLoading: summaryLoading } = useQuery({
    queryKey: ['summary'],
    queryFn: async () => {
      const response = await fetch('/api/summary')
      if (!response.ok) throw new Error('Failed to fetch summary')
      return response.json()
    }
  })

  // Fetch categories
  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const response = await fetch('/api/categories')
      if (!response.ok) throw new Error('Failed to fetch categories')
      return response.json()
    }
  })

  // Fetch Jira data
  const { data: jiraData, isLoading: jiraLoading, error: jiraError } = useQuery({
    queryKey: ['jira-tasks', selectedCategory, selectedTag, dateRange, fetchAllJiraData],
    queryFn: async () => {
      const params = new URLSearchParams()
      
      if (fetchAllJiraData) {
        params.append('fetchAll', 'true')
      } else {
        params.append('limit', '1000') // Default higher limit
      }
      
      if (selectedCategory && selectedCategory !== "all") {
        params.append('project', selectedCategory)
      }
      if (selectedTag) params.append('status', selectedTag)
      if (dateRange.start) params.append('startDate', dateRange.start)
      if (dateRange.end) params.append('endDate', dateRange.end)

      const response = await fetch(`/api/jira?${params}`)
      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'Failed to fetch Jira data')
      }
      return response.json()
    },
    enabled: useJiraData,
    refetchInterval: fetchAllJiraData ? 60000 : 30000, // Slower refresh for all data
  })

  // Fetch metrics with filters
  const { data: metricsData, isLoading: metricsLoading } = useQuery({
    queryKey: ['metrics', selectedCategory, selectedTag, dateRange, currentPage],
    queryFn: async () => {
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: '20'
      })
      if (selectedCategory && selectedCategory !== "all") {
        params.append('categoryId', selectedCategory)
      }
      if (selectedTag) params.append('tag', selectedTag)
      if (dateRange.start) params.append('startDate', dateRange.start)
      if (dateRange.end) params.append('endDate', dateRange.end)

      const response = await fetch(`/api/metrics?${params}`)
      if (!response.ok) throw new Error('Failed to fetch metrics')
      return response.json()
    }
  })

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      const response = await fetch('/api/metrics', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids })
      })
      if (!response.ok) throw new Error('Failed to delete metrics')
      return response.json()
    },
    onSuccess: () => {
      toast.success('Metrics deleted')
      setSelectedMetrics([])
      queryClient.invalidateQueries({ queryKey: ['metrics'] })
      queryClient.invalidateQueries({ queryKey: ['summary'] })
    },
    onError: () => {
      toast.error('Failed to delete metrics')
    }
  })

  const handleSelectMetric = (id: string, checked: boolean) => {
    setSelectedMetrics(prev =>
      checked ? [...prev, id] : prev.filter(mid => mid !== id)
    )
  }

  const handleSelectAll = (checked: boolean) => {
    if (checked && metricsData?.metrics) {
      setSelectedMetrics(metricsData.metrics.map((m: any) => m.id))
    } else {
      setSelectedMetrics([])
    }
  }

  const handleDeleteSelected = () => {
    if (selectedMetrics.length === 0) return
    deleteMutation.mutate(selectedMetrics)
  }

  const handleDeleteSingle = (id: string) => {
    deleteMutation.mutate([id])
  }

  const handleRefreshJiraData = async () => {
    setJiraRefreshing(true)
    try {
      await queryClient.invalidateQueries({ queryKey: ['jira-tasks'] })
      toast.success('Jira data refreshed')
    } catch (error) {
      toast.error('Failed to refresh Jira data')
    } finally {
      setJiraRefreshing(false)
    }
  }

  const handleOpenJiraIssue = (jiraUrl: string) => {
    window.open(jiraUrl, '_blank')
  }

  const handleExport = () => {
    // Create CSV content
    const headers = ['Task ID', 'Category', 'Description', 'Planned Date', 'Actual Date', 'Status', 'Tag']
    const rows = metricsData?.metrics.map((metric: any) => [
      metric.taskId || '-',
      metric.category.name,
      metric.description,
      formatDateForDisplay(new Date(metric.plannedDate)),
      formatDateForDisplay(metric.actualDate ? new Date(metric.actualDate) : null),
      metric.status,
      metric.tag
    ])

    const csvContent = [
      headers.join(','),
      ...(rows?.map((row: any[]) => row.map(cell => `"${cell}"`).join(',')) || [])
    ].join('\n')

    // Download file
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `metrics-export-${format(new Date(), 'yyyy-MM-dd')}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  // Transform Jira data to match CSV summary format
  const transformJiraToSummary = (jiraData: any) => {
    if (!jiraData?.data) return null
    
    const tasks = jiraData.data
    const totalTasks = tasks.length
    
    // Count by status (map to CSV tags)
    const statusCounts: { [key: string]: number } = {
      'on-time': 0,
      'delayed': 0,
      'incomplete': 0,
      'in-progress': 0
    }
    
    // Count by category (project key)
    const categoryCounts: { [key: string]: number } = {}
    
    tasks.forEach((task: any) => {
      // Map Jira status to CSV tags
      const status = task.Status?.toLowerCase() || 'unknown'
      if (status.includes('done') || status.includes('complete')) {
        // Check if it was on time (you may need to adjust this logic based on your data)
        statusCounts['on-time']++
      } else if (status.includes('progress') || status.includes('development')) {
        statusCounts['in-progress']++
      } else if (status.includes('block') || status.includes('stuck')) {
        statusCounts['delayed']++
      } else {
        statusCounts['incomplete']++
      }
      
      // Count by project/category
      const projectKey = task.ProjectCategory || 'Unknown'
      categoryCounts[projectKey] = (categoryCounts[projectKey] || 0) + 1
    })
    
    // Calculate on-time rate
    const completedTasks = statusCounts['on-time'] + statusCounts['delayed']
    const onTimeRate = completedTasks > 0 
      ? Math.round((statusCounts['on-time'] / completedTasks) * 100) 
      : 0
    
    // Format category data
    const metricsByCategory = Object.entries(categoryCounts).map(([category, count]) => ({
      category,
      categoryId: category,
      count
    }))
    
    return {
      summary: {
        totalMetrics: totalTasks,
        onTimeRate,
        targetOnTimeRate: 90,
        metricsByTag: statusCounts,
        metricsByCategory
      }
    }
  }
  
  // Use appropriate data source
  const activeData = useJiraData ? transformJiraToSummary(jiraData) : summaryData
  
  // Prepare chart data
  const pieData = activeData?.summary.metricsByTag 
    ? Object.entries(activeData.summary.metricsByTag).map(([tag, count]) => ({
        name: tag.charAt(0).toUpperCase() + tag.slice(1).replace('-', ' '),
        value: count as number,
        color: TAG_COLORS[tag as keyof typeof TAG_COLORS]
      }))
    : []

  const barData = activeData?.summary.metricsByCategory || []

  return (
    <div className="container mx-auto px-4 py-6 md:py-8">
      <div className="mb-6 md:mb-8">
        <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-2">Projects Dashboard</h1>
        <p className="text-base md:text-lg text-muted-foreground">
          Track and manage your execution metrics with intelligent tagging
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:gap-6 grid-cols-2 lg:grid-cols-4 mb-6 md:mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">On-Time Delivery Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {activeData?.summary.onTimeRate || 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              Target: ≥{activeData?.summary.targetOnTimeRate || 90}%
            </p>
            <div className="mt-2">
              {(activeData?.summary.onTimeRate || 0) >= (activeData?.summary.targetOnTimeRate || 90) ? (
                <Badge className="bg-green-100 text-green-800">On Target</Badge>
              ) : (
                <Badge className="bg-red-100 text-red-800">Below Target</Badge>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Projects</CardTitle>
            <BarChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {activeData?.summary.totalMetrics || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Across {categories.length} categories
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">In Progress</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground"  />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {activeData?.summary.metricsByTag?.['in-progress'] || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Active tasks
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Needs Attention</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(activeData?.summary.metricsByTag?.['delayed'] || 0) + 
               (activeData?.summary.metricsByTag?.['incomplete'] || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              Delayed + Incomplete
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-4 md:gap-6 lg:grid-cols-2 mb-6 md:mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Project Distribution</CardTitle>
            <CardDescription>Breakdown of projects by completion status</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry) => `${entry.name}: ${entry.value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Projects by Category</CardTitle>
            <CardDescription>Distribution across execution OKR categories</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="category" 
                  angle={-45}
                  textAnchor="end"
                  height={100}
                />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Data Source Toggle */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Data Source</span>
            <div className="flex items-center gap-2">
              {useJiraData && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRefreshJiraData}
                  disabled={jiraRefreshing}
                  className="gap-2"
                >
                  <RefreshCw className={`h-4 w-4 ${jiraRefreshing ? 'animate-spin' : ''}`} />
                  {jiraRefreshing ? 'Refreshing...' : 'Refresh'}
                </Button>
              )}
              {useJiraData && jiraLoading && (
                <Badge variant="secondary" className="gap-1">
                  <RefreshCw className="h-3 w-3 animate-spin" />
                  Loading...
                </Badge>
              )}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Data Source Selection */}
            <div className="flex items-center space-x-2">
              <Button
                variant={useJiraData ? "default" : "outline"}
                onClick={() => {
                  setUseJiraData(true)
                  toast.success('Switched to Live Jira Data')
                }}
                size="sm"
                className="gap-2"
              >
                <ExternalLink className="h-4 w-4" />
                Live Jira Data
              </Button>
              <Button
                variant={!useJiraData ? "default" : "outline"}
                onClick={() => {
                  setUseJiraData(false)
                  toast.success('Switched to CSV Data')
                }}
                size="sm"
                className="gap-2"
              >
                <CheckCircle className="h-4 w-4" />
                CSV Data
              </Button>
            </div>
            
            {/* Data Source Info */}
            <div className="text-sm text-muted-foreground">
              {useJiraData ? (
                <div className="flex items-center gap-2">
                  <span>📊 Showing live data from Jira</span>
                  {jiraData?.count && (
                    <Badge variant="outline">
                      {jiraData.count} items loaded
                    </Badge>
                  )}
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <span>📄 Showing uploaded CSV data</span>
                  {activeData?.summary.totalMetrics && (
                    <Badge variant="outline">
                      {activeData.summary.totalMetrics} items
                    </Badge>
                  )}
                </div>
              )}
            </div>
            
            {/* Jira Fetch Options */}
            {useJiraData && (
              <div className="flex items-center space-x-4 p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="fetchAll"
                    checked={fetchAllJiraData}
                    onChange={(e) => setFetchAllJiraData(e.target.checked)}
                    className="rounded"
                  />
                  <label htmlFor="fetchAll" className="text-sm font-medium">
                    Fetch ALL Jira Data
                  </label>
                </div>
                <div className="text-xs text-blue-600">
                  {fetchAllJiraData 
                    ? '⚠️ This will fetch all available data (may take longer)'
                    : '📊 Limited to 1,000 most recent items'
                  }
                </div>
              </div>
            )}
          </div>
          
          {jiraError && (
            <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
              {jiraError.message}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Filters */}
      <Card className="mb-4 md:mb-6">
        <CardHeader>
          <CardTitle className="text-lg md:text-xl">Filters & Controls</CardTitle>
          <CardDescription className="text-sm md:text-base">
            Filter your data and manage display options
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <Label htmlFor="category">{useJiraData ? 'Project' : 'Category'}</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger id="category">
                  <SelectValue placeholder={useJiraData ? "All Projects" : "All Categories"} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{useJiraData ? "All Projects" : "All Categories"}</SelectItem>
                  {useJiraData ? (
                    // Show JIRA project keys for filtering
                    jiraData?.data ? [
                      ...new Set(jiraData.data.map((task: any) => task.Project))
                    ].map((projectKey) => {
                      const key = String(projectKey)
                      const projectName = jiraData.data.find((task: any) => task.Project === projectKey)?.ProjectName || key
                      return (
                        <SelectItem key={key} value={key}>
                          {projectName} ({key})
                        </SelectItem>
                      )
                    }) : []
                  ) : (
                    // Show CSV categories
                    categories.map((category: any) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Tag</Label>
              <Select value={selectedTag} onValueChange={setSelectedTag}>
                <SelectTrigger>
                  <SelectValue placeholder={useJiraData ? "All statuses" : "All tags"} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{useJiraData ? "All statuses" : "All tags"}</SelectItem>
                  {useJiraData ? (
                    // Show JIRA statuses for filtering
                    jiraData?.data ? [
                      ...new Set(jiraData.data.map((task: any) => task.Status))
                    ].map((status) => {
                      const statusStr = String(status)
                      return (
                        <SelectItem key={statusStr} value={statusStr}>
                          {statusStr}
                        </SelectItem>
                      )
                    }) : []
                  ) : (
                    // Show CSV tags
                    <>
                      <SelectItem value="on-time">On Time</SelectItem>
                      <SelectItem value="delayed">Delayed</SelectItem>
                      <SelectItem value="incomplete">Incomplete</SelectItem>
                      <SelectItem value="in-progress">In Progress</SelectItem>
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Start Date</Label>
              <Input
                type="date"
                value={dateRange.start}
                onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
              />
            </div>

            <div>
              <Label>End Date</Label>
              <Input
                type="date"
                value={dateRange.end}
                onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Metrics Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>{useJiraData ? 'Live Jira Tasks' : 'Metrics'}</CardTitle>
              <CardDescription>
                {useJiraData 
                  ? `${jiraData?.count || 0} total tasks from Jira`
                  : `${metricsData?.pagination.total || 0} total metrics`
                }
                {useJiraData && jiraLoading && ' (Refreshing...)'}
              </CardDescription>
            </div>
            {!useJiraData && (
              <Button onClick={handleExport} size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export CSV
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {/* Delete functionality disabled */}
          {/* {!useJiraData && (
            <div className="mb-4 flex items-center gap-2">
              <Button
                variant="destructive"
                size="sm"
                onClick={handleDeleteSelected}
                disabled={selectedMetrics.length === 0 || deleteMutation.isPending}
              >
                Delete Selected
              </Button>
              {deleteMutation.isPending && <span className="text-xs text-muted-foreground">Deleting...</span>}
            </div>
          )} */}
          
          {jiraLoading && useJiraData ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin mr-2" />
              <span>Loading Jira data...</span>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    {!useJiraData && (
                      <TableHead>
                        <input
                          type="checkbox"
                          checked={metricsData?.metrics?.length > 0 && selectedMetrics.length === metricsData.metrics.length}
                          onChange={e => handleSelectAll(e.target.checked)}
                          aria-label="Select all metrics"
                        />
                      </TableHead>
                    )}
                    <TableHead>Task ID</TableHead>
                    <TableHead>{useJiraData ? 'Project' : 'Category'}</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Planned Date</TableHead>
                    <TableHead>Actual Date</TableHead>
                    <TableHead>Status</TableHead>
                    {!useJiraData && <TableHead>Tag</TableHead>}
                    {!useJiraData && <TableHead>Action</TableHead>}
                    {useJiraData && <TableHead>Jira Link</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {useJiraData ? (
                    // Display Jira data
                    jiraData?.data?.map((task: any, index: number) => (
                      <TableRow key={task.Task_ID || index}>
                        <TableCell className="font-mono text-sm">
                          <button
                            onClick={() => handleOpenJiraIssue(task.jira_url)}
                            className="text-primary hover:text-primary/80 underline font-medium"
                          >
                            {task.Task_ID}
                          </button>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">Jira Project</Badge>
                        </TableCell>
                        <TableCell className="max-w-xs truncate" title={task.Description}>
                          {task.Description}
                        </TableCell>
                        <TableCell>
                          {task.Planned_Date ? formatDateForDisplay(new Date(task.Planned_Date)) : '-'}
                        </TableCell>
                        <TableCell>
                          {task.Actual_Date ? formatDateForDisplay(new Date(task.Actual_Date)) : '-'}
                        </TableCell>
                        <TableCell>
                          <Badge variant={task.Status === 'Done' ? 'default' : 'secondary'}>
                            {task.Status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleOpenJiraIssue(task.jira_url)}
                            className="gap-2"
                          >
                            <ExternalLink className="h-3 w-3" />
                            View in Jira
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    // Display CSV data
                    metricsData?.metrics.map((metric: any) => (
                      <TableRow key={metric.id}>
                        <TableCell>
                          <input
                            type="checkbox"
                            checked={selectedMetrics.includes(metric.id)}
                            onChange={e => handleSelectMetric(metric.id, e.target.checked)}
                            aria-label={`Select metric ${metric.taskId || metric.id}`}
                          />
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {metric.taskId || '-'}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{metric.category.name}</Badge>
                        </TableCell>
                        <TableCell className="max-w-xs truncate">
                          {metric.description}
                        </TableCell>
                        <TableCell>
                          {formatDateForDisplay(new Date(metric.plannedDate))}
                        </TableCell>
                        <TableCell>
                          {formatDateForDisplay(metric.actualDate ? new Date(metric.actualDate) : null)}
                        </TableCell>
                        <TableCell>{metric.status}</TableCell>
                        <TableCell>
                          <Badge className={getTagColor(metric.tag as any)}>
                            {metric.tag.charAt(0).toUpperCase() + metric.tag.slice(1).replace('-', ' ')}
                          </Badge>
                        </TableCell>
                        {/* Delete button disabled */}
                        {/* <TableCell>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteSingle(metric.id)}
                            disabled={deleteMutation.isPending}
                          >
                            Delete
                          </Button>
                        </TableCell> */}
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}

          {/* Pagination */}
          {metricsData && metricsData.pagination.totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <p className="text-sm text-muted-foreground">
                Page {metricsData.pagination.page} of {metricsData.pagination.totalPages}
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => prev + 1)}
                  disabled={currentPage === metricsData.pagination.totalPages}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>


    </div>
  )
} 