'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { TrendingUp, TrendingDown, Minus, Loader2 } from 'lucide-react'

interface DashboardMetric {
  id: string
  name: string
  avgScore: number
  status: string
  unit: string
  description?: string
}

interface AnalyticsDashboardProps {
  onSelectMetric?: (metricId: string) => void
}

export function AnalyticsDashboard({ onSelectMetric }: AnalyticsDashboardProps) {
  const [metrics, setMetrics] = useState<DashboardMetric[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadDashboardData()
  }, [])

  const loadDashboardData = async () => {
    setIsLoading(true)
    setError(null)
    
    try {
      const response = await fetch('/api/analytics/dashboard')
      const result = await response.json()
      
      if (result.success) {
        setMetrics(result.data)
      } else {
        setError(result.error || 'Failed to load dashboard data')
      }
    } catch (err) {
      setError('Error loading dashboard data')
      console.error('Error loading dashboard data:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'high':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
      case 'low':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
      case 'positive':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
      case 'negative':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
      case 'neutral':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'high':
      case 'positive':
        return <TrendingUp className="h-4 w-4" />
      case 'low':
      case 'negative':
        return <TrendingDown className="h-4 w-4" />
      case 'neutral':
        return <Minus className="h-4 w-4" />
      default:
        return <Minus className="h-4 w-4" />
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Loader2 className="h-12 w-12 mx-auto mb-4 animate-spin" />
          <p className="text-lg font-medium">Loading Analytics Dashboard</p>
          <p className="text-sm text-muted-foreground">Please wait...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <p className="text-lg font-medium text-red-600">Error Loading Dashboard</p>
          <p className="text-sm text-muted-foreground">{error}</p>
          <button 
            onClick={loadDashboardData}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Retry
          </button>
        </div>
      </div>
    )
  }

  if (metrics.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <p className="text-lg font-medium">No Analytics Data Available</p>
          <p className="text-sm text-muted-foreground">
            No metrics found in your database. Please ensure you have seeded data or uploaded metrics.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4 md:space-y-6">
      <div>
        <h2 className="text-xl md:text-2xl font-bold mb-2">Analytics Overview</h2>
        <p className="text-sm md:text-base text-muted-foreground">
          Real-time business metrics calculated from your data
        </p>
      </div>

      <div className="grid gap-3 md:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {metrics.map((metric) => (
          <Card 
            key={metric.id} 
            className="cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => onSelectMetric?.(metric.id)}
          >
            <CardHeader className="pb-2 md:pb-3">
              <CardTitle className="text-xs md:text-sm font-medium leading-tight">
                {metric.name}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 md:space-y-3">
              <div className="text-center">
                <div className="text-xl md:text-2xl font-bold">
                  {metric.avgScore}
                </div>
                <div className="text-xs text-muted-foreground">
                  {metric.unit}
                </div>
              </div>
              
              <div className="flex justify-center">
                <Badge 
                  variant="secondary" 
                  className={`${getStatusColor(metric.status)} flex items-center gap-1 text-xs`}
                >
                  {getStatusIcon(metric.status)}
                  {metric.status}
                </Badge>
              </div>
              
              {/* Detailed description in specified format */}
              {metric.description && (
                <div className="text-xs text-muted-foreground mt-3 pt-2 border-t border-gray-100">
                  <div className="text-center">
                    {metric.description}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {metrics.length > 0 && (
        <div className="text-center text-xs md:text-sm text-muted-foreground px-4">
          Click on any metric card to view detailed analytics and calculations
        </div>
      )}
    </div>
  )
}
