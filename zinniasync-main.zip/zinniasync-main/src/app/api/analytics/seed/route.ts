import { NextResponse } from 'next/server'
import { seedAnalyticsData } from '@/lib/seed-analytics'

export async function POST() {
  try {
    await seedAnalyticsData()
    return NextResponse.json({
      success: true,
      message: 'Analytics data seeded successfully'
    })
  } catch (error) {
    console.error('Error seeding analytics data:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to seed analytics data',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
