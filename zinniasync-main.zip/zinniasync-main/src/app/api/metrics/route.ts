import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const categoryId = searchParams.get('categoryId')
    const tag = searchParams.get('tag')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '50')

    // Build where clause
    const where: any = {}
    
    if (categoryId) {
      where.categoryId = categoryId
    }
    
    if (tag) {
      where.tag = tag
    }
    
    if (startDate || endDate) {
      where.plannedDate = {}
      if (startDate) {
        where.plannedDate.gte = new Date(startDate)
      }
      if (endDate) {
        where.plannedDate.lte = new Date(endDate)
      }
    }

    // Get total count
    const total = await prisma.metric.count({ where })

    // Get paginated metrics
    const metrics = await prisma.metric.findMany({
      where,
      include: {
        category: true
      },
      orderBy: {
        plannedDate: 'desc'
      },
      skip: (page - 1) * limit,
      take: limit
    })

    return NextResponse.json({
      metrics,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Metrics fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch metrics' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { ids } = await request.json()
    if (!Array.isArray(ids) || ids.length === 0) {
      return NextResponse.json({ error: 'No metric IDs provided' }, { status: 400 })
    }
    await prisma.metric.deleteMany({ where: { id: { in: ids } } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Metrics delete error:', error)
    return NextResponse.json({ error: 'Failed to delete metrics' }, { status: 500 })
  }
} 