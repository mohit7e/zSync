import { PrismaClient } from '@prisma/client'
import * as fs from 'fs'
import * as path from 'path'

const prisma = new PrismaClient()

// Mapping of CSV files to business types
const BUSINESS_TYPE_MAPPING = {
  'Engineering Delivery Predictability Dataset.csv': 'engineering-delivery',
  'Release Velocity Bi-weekly Dataset.csv': 'release-velocity',
  'Production Quality and Reliability Dataset.csv': 'production-quality',
  'TPA Operational Efficiency & SLA Compliance Dataset.csv': 'tpa-efficiency',
  'Call Center Service Level & Customer Experience Dataset.csv': 'call-center',
  'Cross-Functional Program Delivery Dataset.csv': 'cross-functional',
  'Sales Pipeline Conversion & Cycle Time Dataset.csv': 'sales-pipeline',
  'Marketing Campaign Execution & Readiness Dataset.csv': 'marketing-campaign'
}

function parseCSV(csvContent: string): any[] {
  const lines = csvContent.split('\n').filter(line => line.trim())
  if (lines.length < 2) return []
  
  const headers = lines[0].split(',').map(h => h.trim())
  const data = []
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim())
    const row: any = {}
    
    headers.forEach((header, index) => {
      row[header] = values[index] || ''
    })
    
    data.push(row)
  }
  
  return data
}

export async function seedAnalyticsData() {
  console.log('🌱 Seeding analytics data...')
  
  // Clear existing analytics data
  await prisma.analyticsData.deleteMany()
  console.log('🗑️  Cleared existing analytics data')
  
  const preloadedDir = path.join(process.cwd(), 'preloaded_analytics')
  
  if (!fs.existsSync(preloadedDir)) {
    console.error('❌ Preloaded analytics directory not found:', preloadedDir)
    return
  }
  
  const files = fs.readdirSync(preloadedDir).filter(file => file.endsWith('.csv'))
  
  for (const file of files) {
    const businessType = BUSINESS_TYPE_MAPPING[file as keyof typeof BUSINESS_TYPE_MAPPING]
    
    if (!businessType) {
      console.warn(`⚠️  No mapping found for file: ${file}`)
      continue
    }
    
    const filePath = path.join(preloadedDir, file)
    const csvContent = fs.readFileSync(filePath, 'utf-8')
    const data = parseCSV(csvContent)
    
    console.log(`📊 Processing ${file} (${data.length} rows) -> ${businessType}`)
    
    // Insert data into database
    for (let i = 0; i < data.length; i++) {
      await prisma.analyticsData.create({
        data: {
          businessType,
          rowIndex: i,
          data: data[i]
        }
      })
    }
    
    console.log(`✅ Seeded ${data.length} rows for ${businessType}`)
  }
  
  console.log('🎉 Analytics data seeding completed!')
}

export async function getAnalyticsData(businessType: string): Promise<any[]> {
  const records = await prisma.analyticsData.findMany({
    where: { businessType },
    orderBy: { rowIndex: 'asc' }
  })
  
  return records.map(record => record.data)
}

// For data management - allows updating specific business type data
export async function updateAnalyticsData(businessType: string, newData: any[]) {
  console.log(`🔄 Updating analytics data for ${businessType}...`)
  
  // Delete existing data for this business type
  await prisma.analyticsData.deleteMany({
    where: { businessType }
  })
  
  // Insert new data
  for (let i = 0; i < newData.length; i++) {
    await prisma.analyticsData.create({
      data: {
        businessType,
        rowIndex: i,
        data: newData[i]
      }
    })
  }
  
  console.log(`✅ Updated ${newData.length} rows for ${businessType}`)
}
