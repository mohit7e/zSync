import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { parseCSVData } from '@/lib/csv-parsers'

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { csvData, categoryId, categoryName } = data

    if (!csvData || !categoryId || !categoryName) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Parse the CSV data based on category
    const parsedMetrics = await parseCSVData(csvData, categoryName, categoryId)

    // Save metrics to database
    const createdMetrics = await prisma.metric.createMany({
      data: parsedMetrics,
      skipDuplicates: true
    })

    return NextResponse.json({
      success: true,
      count: createdMetrics.count,
      message: `Successfully imported ${createdMetrics.count} metrics`
    })
  } catch (error) {
    console.error('Upload error:', error)
    return NextResponse.json(
      { error: 'Failed to process upload' },
      { status: 500 }
    )
  }
} 