import { format, isAfter, isBefore, isEqual, startOfDay } from 'date-fns'

export type MetricTag = 'on-time' | 'delayed' | 'incomplete' | 'in-progress'

export function calculateMetricTag(
  plannedDate: Date,
  actualDate: Date | null
): MetricTag {
  const currentDate = startOfDay(new Date())
  const planned = startOfDay(plannedDate)

  // If actual_date exists
  if (actualDate) {
    const actual = startOfDay(actualDate)
    
    // IF actual_date <= planned_date → "on-time"
    if (isBefore(actual, planned) || isEqual(actual, planned)) {
      return 'on-time'
    }
    
    // IF actual_date > planned_date → "delayed"
    if (isAfter(actual, planned)) {
      return 'delayed'
    }
  }

  // If actual_date is null
  if (!actualDate) {
    // IF current_date > planned_date → "incomplete"
    if (isAfter(currentDate, planned)) {
      return 'incomplete'
    }
    
    // IF current_date <= planned_date → "in-progress"
    if (isBefore(currentDate, planned) || isEqual(currentDate, planned)) {
      return 'in-progress'
    }
  }

  // Default fallback (should not reach here)
  return 'in-progress'
}

export function getTagColor(tag: MetricTag): string {
  switch (tag) {
    case 'on-time':
      return 'bg-green-100 text-green-800 border-green-200'
    case 'delayed':
      return 'bg-red-100 text-red-800 border-red-200'
    case 'incomplete':
      return 'bg-orange-100 text-orange-800 border-orange-200'
    case 'in-progress':
      return 'bg-blue-100 text-blue-800 border-blue-200'
    default:
      return 'bg-gray-100 text-gray-800 border-gray-200'
  }
}

export function formatDateForDisplay(date: Date | null): string {
  if (!date) return '-'
  return format(date, 'MMM dd, yyyy')
} 