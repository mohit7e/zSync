'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { AlertCircle, CheckCircle, TrendingUp, TrendingDown, Minus } from 'lucide-react'
import {
  calculateEngineeringPredictability,
  calculateReleaseVelocityScore,
  calculateProductionQuality,
  calculateEfficiencyScore,
  calculateCallCenterScore,
  calculateCrossFunctionalSuccess,
  calculateSalesCycleConversion,
  calculateMarketingTurnoverSuccess,
} from '@/utils/scoreFormulas'
import axios from 'axios'

interface AnalyticsCalculatorProps {
  analyticType: string
  data: any[]
  analyticData: {
    id: string
    name: string
    description: string
    formula: string
    variables: string
    scoreRange?: string
    interpretation?: string
  }
}

type ReleaseVelocityResult = {
  id: number
  planned: number
  unplanned: number
  deltaScore: number
  successPercent: number
  status: 'positive' | 'negative'
}


interface GenerateInsightParams extends AnalyticsCalculatorProps {
  results: ReleaseVelocityResult[]
}


export function AnalyticsCalculator({ analyticType, data, analyticData }: AnalyticsCalculatorProps) {
  const [results, setResults] = useState<any[]>([])
  const [summary, setSummary] = useState<any>(null)
  const [summaryInsight, setSummaryInsight] = useState<string>('')

  useEffect(() => {
    calculateScores()
  }, [analyticType, data])

  useEffect(() => {
  if (results.length > 0) {
    generateInsight({ analyticType, analyticData, data, results })
  }
}, [results, analyticType, analyticData, data])


  const calculateScores = () => {
    if (!data || data.length === 0) return

    let calculatedResults: any[] = []
    let summaryData: any = {}

    switch (analyticType) {
      case 'engineering-delivery':
        calculatedResults = data.map((row, index) => {
          const T = parseFloat(row.Time_Duration_T_days) || 0
          const E = parseFloat(row.Excess_Time_E_days) || 0
          const C = parseFloat(row.Complexity_Value) || 0
          const score = calculateEngineeringPredictability(T, E, C)
          return {
            id: index,
            complexity: row.Complexity,
            timeAssigned: T,
            excessTime: E,
            complexityValue: C,
            score: score,
            status: score >= 8 ? 'high' : score >= 5 ? 'medium' : 'low'
          }
        })
        summaryData = {
          avgScore: calculatedResults.reduce((sum, r) => sum + r.score, 0) / calculatedResults.length,
          highPerformance: calculatedResults.filter(r => r.status === 'high').length,
          totalProjects: calculatedResults.length
        }
        break

      case 'release-velocity':
        calculatedResults = data.map((row, index) => {
          const P = parseFloat(row.Planned_Releases) || 0
          const U = parseFloat(row.Unplanned_Releases) || 0
          const result = calculateReleaseVelocityScore(P, U)
          return {
            id: index,
            planned: P,
            unplanned: U,
            deltaScore: result.deltaScore,
            successPercent: result.successPercent,
            status: result.deltaScore >= 0 ? 'positive' : 'negative'
          }
        })
        summaryData = {
          avgDelta: calculatedResults.reduce((sum, r) => sum + r.deltaScore, 0) / calculatedResults.length,
          avgSuccessPercent: calculatedResults.reduce((sum, r) => sum + r.successPercent, 0) / calculatedResults.length,
          positiveReleases: calculatedResults.filter(r => r.status === 'positive').length
        }
        break

      case 'production-quality':
        calculatedResults = data.map((row, index) => {
          const I = parseFloat(row.Total_Incidents_I) || 0
          const F_I = parseFloat(row.Incidents_Fixed_F) || 0
          const fixedSeverityCounts = {
            1: parseFloat(row.Sev1_Incidents) || 0,
            2: parseFloat(row.Sev2_Incidents) || 0,
            3: parseFloat(row.Sev3_Incidents) || 0,
            4: parseFloat(row.Sev4_Incidents) || 0,
          }
          const score = calculateProductionQuality(I, fixedSeverityCounts, F_I)
          return {
            id: index,
            totalIncidents: I,
            fixedIncidents: F_I,
            severity1: fixedSeverityCounts[1],
            severity2: fixedSeverityCounts[2],
            severity3: fixedSeverityCounts[3],
            severity4: fixedSeverityCounts[4],
            score: score,
            status: score >= 0.25 ? 'high' : score >= 0.15 ? 'medium' : 'low'
          }
        })
        summaryData = {
          avgScore: calculatedResults.reduce((sum, r) => sum + r.score, 0) / calculatedResults.length,
          highQuality: calculatedResults.filter(r => r.status === 'high').length,
          totalPeriods: calculatedResults.length
        }
        break

      case 'tpa-efficiency':
        calculatedResults = data.map((row, index) => {
          const V = parseFloat(row.Volume_V) || 0
          const P = parseFloat(row.People_P) || 0
          const score = calculateEfficiencyScore(V, P)
          return {
            id: index,
            outputVolume: V,
            numberOfPeople: P,
            score: score,
            status: score >= 50 ? 'high' : score >= 25 ? 'medium' : 'low'
          }
        })
        summaryData = {
          avgEfficiency: calculatedResults.reduce((sum, r) => sum + r.score, 0) / calculatedResults.length,
          highEfficiency: calculatedResults.filter(r => r.status === 'high').length,
          totalTeams: calculatedResults.length
        }
        break

      case 'call-center':
        calculatedResults = data.map((row, index) => {
          const T = parseFloat(row.Total_Calls_T) || 0
          const A = parseFloat(row.Calls_Per_Agent_A) || 0
          const qualityType = row.Call_Quality_Type?.toLowerCase()
          const quality = qualityType === 'standard' ? 'Standard' : 
                         qualityType === 'gold' ? 'Gold' : 'Platinum'
          const score = calculateCallCenterScore(T, A, quality as any)
          return {
            id: index,
            totalCalls: T,
            callsPerAgent: A,
            quality: quality,
            score: score,
            status: score === null ? 'excluded' : score >= 2 ? 'high' : score >= 1 ? 'medium' : 'low',
            excluded: score === null
          }
        })
        const validResults = calculatedResults.filter(r => !r.excluded)
        summaryData = {
          avgScore: validResults.length > 0 ? validResults.reduce((sum, r) => sum + (r.score || 0), 0) / validResults.length : 0,
          highPerformance: validResults.filter(r => r.status === 'high').length,
          excludedDays: calculatedResults.filter(r => r.excluded).length,
          totalDays: calculatedResults.length
        }
        break

      case 'cross-functional':
        calculatedResults = data.map((row, index) => {
          const T = parseFloat(row.Time_Assigned_T_days) || 0
          const E = parseFloat(row.Excess_Time_E_days) || 0
          const score = calculateCrossFunctionalSuccess(T, E)
          return {
            id: index,
            timeAssigned: T,
            excessTime: E,
            score: score,
            status: score >= 90 ? 'high' : score >= 70 ? 'medium' : 'low'
          }
        })
        summaryData = {
          avgScore: calculatedResults.reduce((sum, r) => sum + r.score, 0) / calculatedResults.length,
          onTimeProjects: calculatedResults.filter(r => r.status === 'high').length,
          totalProjects: calculatedResults.length
        }
        break

      case 'sales-pipeline':
        calculatedResults = data.map((row, index) => {
          const T = parseFloat(row.Product_P) || 0
          const B = parseFloat(row.Backfill_B) || 0
          const score = calculateSalesCycleConversion(T, B)
          return {
            id: index,
            totalProduct: T,
            backfill: B,
            score: score,
            status: score >= 80 ? 'high' : score >= 60 ? 'medium' : 'low'
          }
        })
        summaryData = {
          avgScore: calculatedResults.reduce((sum, r) => sum + r.score, 0) / calculatedResults.length,
          highConversion: calculatedResults.filter(r => r.status === 'high').length,
          totalCycles: calculatedResults.length
        }
        break

      case 'marketing-campaign':
        calculatedResults = data.map((row, index) => {
          const IF = parseFloat(row.IF) || 0
          const OFC = parseFloat(row.OFC) || 0
          const score = calculateMarketingTurnoverSuccess(IF, OFC)
          return {
            id: index,
            initialPotential: IF,
            enforcedPolicy: OFC,
            score: score,
            status: score >= 100 ? 'high' : score >= 50 ? 'medium' : 'low'
          }
        })
        summaryData = {
          avgScore: calculatedResults.reduce((sum, r) => sum + r.score, 0) / calculatedResults.length,
          highConversion: calculatedResults.filter(r => r.status === 'high').length,
          totalCampaigns: calculatedResults.length
        }
        break
    }

    setResults(calculatedResults)
    setSummary(summaryData)
  }


// const generateInsight = async ({ analyticType, analyticData, data, results }: GenerateInsightParams) => {
//   try {
//     const prompt = `
// You are a helpful analytics assistant. Based on the OKR data below, write a simple summary (10–15 lines) of performance.

// OKR Name: ${analyticType}
// Description: ${analyticData.description}
// Formula: ${analyticData.formula}
// Score Range: ${analyticData.scoreRange}
// Interpretation Guidance: ${analyticData.interpretation}

// Here is the calculated results : ${JSON.stringify(results.slice(0, 5), null, 2)}
// Here is the raw data from the api : ${JSON.stringify(data.slice(0, 5), null, 2)}

// Now, summarize whether performance is good or needs improvement, explain why, and provide one tip to improve if needed. Be clear and concise.
// `

//     const response = await axios.post(
//       'https://api.openai.com/v1/chat/completions',
//       {
//         model: 'gpt-4',
//         messages: [{ role: 'user', content: prompt }],
//         temperature: 0.7,
//       },
//       {
//         headers: {
//           Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, 
//           'Content-Type': 'application/json',
//         },
//       }
//     )

//     const insight = response.data.choices[0].message.content
//     setSummaryInsight(insight)
//   } catch (error) {
//     console.error('Error generating insight:', error)
//     setSummaryInsight('Failed to generate insight.')
//   }
// }

const generateInsight = async ({ analyticType, analyticData, data, results }: GenerateInsightParams) => {
  try {
    const prompt = `
You are a helpful analytics assistant. Based on the OKR data below, write a simple summary (10–15 lines) of performance.

OKR Name: ${analyticType}
Description: ${analyticData.description}
Formula: ${analyticData.formula}
Score Range: ${analyticData.scoreRange}
Interpretation Guidance: ${analyticData.interpretation}

Here is the calculated results : ${JSON.stringify(results.slice(0, 5), null, 2)}
Here is the raw data from the api : ${JSON.stringify(data.slice(0, 5), null, 2)}

Now, summarize whether performance is good or needs improvement, explain why, and provide one tip to improve if needed. Be clear and concise.
`

    const response = await axios.post('/api/generateInsight', { prompt })
    const insight = response.data.insight
    setSummaryInsight(insight)
  } catch (error) {
    console.error('Error generating insight:', error)
    setSummaryInsight('Failed to generate insight.')
  }
}


  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'high':
      case 'positive':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'medium':
        return <Minus className="h-4 w-4 text-yellow-500" />
      case 'low':
      case 'negative':
        return <TrendingDown className="h-4 w-4 text-red-500" />
      case 'excluded':
        return <AlertCircle className="h-4 w-4 text-gray-500" />
      default:
        return <TrendingUp className="h-4 w-4 text-blue-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'high':
      case 'positive':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
      case 'low':
      case 'negative':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
      case 'excluded':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
      default:
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
    }
  }

  if (!results.length) {
    return (
      <div className="text-center py-8">
        <AlertCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
        <p className="text-lg font-medium">No data to calculate</p>
        <p className="text-sm text-muted-foreground">Please check your CSV format</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Summary Card */}
      <Card>
        <CardHeader>
          <CardTitle>Summary</CardTitle>
          <CardDescription>{analyticData.name}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {summary && Object.entries(summary).map(([key, value]: [string, any]) => (
              <div key={key} className="text-center">
                <div className="text-2xl font-bold text-primary">
                  {typeof value === 'number' ? value.toFixed(2) : value}
                </div>
                <div className="text-sm text-muted-foreground capitalize">
                  {key.replace(/([A-Z])/g, ' $1').toLowerCase()}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

<Card>
  <CardHeader>
    <CardTitle>AI Insights</CardTitle>
    <CardDescription>{analyticData.name}</CardDescription>
  </CardHeader>
  <CardContent>
    {!summaryInsight ? (
      <div className="space-y-2 animate-pulse">
        {[...Array(10)].map((_, i) => (
          <div
            key={i}
            className="h-4 bg-muted rounded"
            style={{ width: `${80 - (i % 3) * 10}%` }}
          />
        ))}
      </div>
    ) : (
      <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">
        {summaryInsight}
      </p>
    )}
  </CardContent>
</Card>

      {/* Results Table */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Results</CardTitle>
          <CardDescription>Individual calculations for each data row</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {results.map((result) => (
              <div key={result.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  {getStatusIcon(result.status)}
                  <div>
                    <div className="font-medium">
                      Score: {typeof result.score === 'number' ? result.score.toFixed(3) : 'N/A'}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Row {result.id + 1}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Badge className={getStatusColor(result.status)}>
                    {result.status}
                  </Badge>
                  {result.excluded && (
                    <Badge variant="outline">
                      Excluded
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}