import { calculateMetricTag } from './tagging'
import { parse } from 'date-fns'

interface BaseMetric {
  source: string
  metricType: string
  taskId?: string
  description: string
  plannedDate: Date
  actualDate: Date | null
  status: string
  value?: number
  target?: number
  unit?: string
  metadata?: any
}

// Parse date with multiple format support
function parseDate(dateStr: string | undefined | null): Date | null {
  if (!dateStr || dateStr.trim() === '') return null
  
  const formats = [
    'yyyy-MM-dd',
    'MM/dd/yyyy',
    'MM-dd-yyyy',
    'dd/MM/yyyy',
    'yyyy/MM/dd'
  ]
  
  for (const format of formats) {
    try {
      const date = parse(dateStr, format, new Date())
      if (!isNaN(date.getTime())) {
        return date
      }
    } catch (e) {
      continue
    }
  }
  
  // Try native Date parsing as last resort
  const date = new Date(dateStr)
  return isNaN(date.getTime()) ? null : date
}

// Engineering CSV Parser
export function parseEngineeringCSV(data: any[], categoryId: string): BaseMetric[] {
  return data.map(row => {
    const plannedDate = parseDate(row.Planned_Date) || new Date()
    const actualDate = parseDate(row.Actual_Date)
    
    return {
      source: 'Engineering CSV',
      metricType: 'Feature Delivery',
      taskId: row.Task_ID || row.ID,
      description: row.Description || row.Task_Name || 'Engineering Task',
      plannedDate,
      actualDate,
      status: row.Status || (actualDate ? 'Completed' : 'In Progress'),
      value: parseFloat(row.Complexity) || parseFloat(row.Story_Points) || 0,
      target: parseFloat(row.Time_Duration_T_days) || 0,
      unit: 'days',
      metadata: {
        complexity: row.Complexity,
        timeDuration: row.Time_Duration_T_days,
        excessTime: row.Excess_Time_E_days
      }
    }
  })
}

// Call Center CSV Parser
export function parseCallCenterCSV(data: any[], categoryId: string): BaseMetric[] {
  return data.map(row => {
    const plannedDate = parseDate(row.Target_Date) || new Date()
    const actualDate = parseDate(row.Achievement_Date)
    
    return {
      source: 'Call Center CSV',
      metricType: row.Call_Quality_Type || 'Service Metric',
      taskId: row.Agent_ID,
      description: `${row.Call_Quality_Type || 'Call Center Metric'} - Agent ${row.Agent_ID || 'Unknown'}`,
      plannedDate,
      actualDate,
      status: row.Status || (actualDate ? 'Achieved' : 'Pending'),
      value: parseFloat(row.Quality_Value_C) || parseFloat(row.Total_Calls_T) || 0,
      target: parseFloat(row.Target_Quality) || parseFloat(row.Calls_Per_Agent_A) || 0,
      unit: row.Call_Quality_Type === 'FCR' ? '%' : 'calls',
      metadata: {
        totalCalls: row.Total_Calls_T,
        callsPerAgent: row.Calls_Per_Agent_A,
        qualityType: row.Call_Quality_Type,
        qualityValue: row.Quality_Value_C
      }
    }
  })
}

// Production CSV Parser
export function parseProductionCSV(data: any[], categoryId: string): BaseMetric[] {
  return data.map(row => {
    const plannedDate = parseDate(row.Target_Date) || new Date()
    const actualDate = parseDate(row.Resolution_Date)
    
    return {
      source: 'Production CSV',
      metricType: 'Incident Management',
      taskId: row.Incident_ID,
      description: row.Description || `Production Incident ${row.Incident_ID || ''}`,
      plannedDate,
      actualDate,
      status: row.Status || (actualDate ? 'Resolved' : 'Open'),
      value: parseFloat(row.Total_Incidents_I) || 1,
      target: 0, // Target is 0 incidents
      unit: 'incidents',
      metadata: {
        severity: row.Severity,
        sev1: row.Sev1_Incidents,
        sev2: row.Sev2_Incidents,
        sev3: row.Sev3_Incidents,
        sev4: row.Sev4_Incidents,
        incidentsFixed: row.Incidents_Fixed_F
      }
    }
  })
}

// Release CSV Parser
export function parseReleaseCSV(data: any[], categoryId: string): BaseMetric[] {
  return data.map(row => {
    const plannedDate = parseDate(row.Planned_Release_Date) || new Date()
    const actualDate = parseDate(row.Actual_Release_Date)
    
    return {
      source: 'Release CSV',
      metricType: 'Release Deployment',
      taskId: row.Release_ID,
      description: row.Release_Name || `Release ${row.Release_ID || ''}`,
      plannedDate,
      actualDate,
      status: row.Status || (actualDate ? 'Deployed' : 'Pending'),
      value: parseFloat(row.Features_Count) || 0,
      target: parseFloat(row.Target_Features) || 0,
      unit: 'features',
      metadata: {
        environment: row.Environment,
        deploymentType: row.Deployment_Type
      }
    }
  })
}

// Generic CSV Parser for other types
export function parseGenericCSV(data: any[], categoryId: string, source: string): BaseMetric[] {
  return data.map(row => {
    // Try to find date fields
    const plannedDateField = Object.keys(row).find(key => 
      key.toLowerCase().includes('planned') || 
      key.toLowerCase().includes('target') ||
      key.toLowerCase().includes('due')
    )
    const actualDateField = Object.keys(row).find(key => 
      key.toLowerCase().includes('actual') || 
      key.toLowerCase().includes('completed') ||
      key.toLowerCase().includes('achieved')
    )
    
    const plannedDate = parseDate(row[plannedDateField || '']) || new Date()
    const actualDate = parseDate(row[actualDateField || ''])
    
    // Find ID field
    const idField = Object.keys(row).find(key => 
      key.toLowerCase().includes('id') || 
      key.toLowerCase() === 'id'
    )
    
    // Find description field
    const descField = Object.keys(row).find(key => 
      key.toLowerCase().includes('desc') || 
      key.toLowerCase().includes('name') ||
      key.toLowerCase().includes('title')
    )
    
    return {
      source: `${source} CSV`,
      metricType: source,
      taskId: row[idField || ''] || undefined,
      description: row[descField || ''] || `${source} Metric`,
      plannedDate,
      actualDate,
      status: row.Status || (actualDate ? 'Completed' : 'In Progress'),
      value: parseFloat(row.Value) || parseFloat(row.Score) || 0,
      target: parseFloat(row.Target) || 0,
      unit: row.Unit || 'units',
      metadata: row
    }
  })
}

// Main parser function that routes to specific parsers
export async function parseCSVData(
  data: any[],
  categoryName: string,
  categoryId: string
): Promise<any[]> {
  let metrics: BaseMetric[] = []
  
  switch (categoryName) {
    case 'Engineering':
      metrics = parseEngineeringCSV(data, categoryId)
      break
    case 'Call Center':
      metrics = parseCallCenterCSV(data, categoryId)
      break
    case 'Production':
      metrics = parseProductionCSV(data, categoryId)
      break
    case 'Release':
      metrics = parseReleaseCSV(data, categoryId)
      break
    default:
      metrics = parseGenericCSV(data, categoryId, categoryName)
  }
  
  // Apply tagging logic to all metrics
  return metrics.map(metric => ({
    ...metric,
    tag: calculateMetricTag(metric.plannedDate, metric.actualDate),
    categoryId
  }))
} 