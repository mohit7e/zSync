'use client'

import Link from 'next/link'
import { Upload } from 'lucide-react'
import { Button } from './ui/button'

export function FloatingUploadButton() {
  return (
    <Link href="/upload" className="hidden md:block fixed bottom-6 right-6 z-50 group">
      <Button
        size="lg"
        className="h-14 w-14 rounded-full shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105 relative"
        title="Upload"
      >
        <Upload className="h-6 w-6" />
        <span className="sr-only">Upload</span>
        {/* Custom tooltip */}
        <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-2 py-1 bg-black text-white text-sm rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap pointer-events-none">
          Upload
          <div className="absolute left-full top-1/2 -translate-y-1/2 border-4 border-transparent border-l-black"></div>
        </div>
      </Button>
    </Link>
  )
}
