// Score calculation formulas for business analytics

// 1. Engineering Delivery Predictability
export function calculateEngineeringPredictability(T: number, E: number, C: number): number {
  return ((T - E) / T) * C;
}

// 2. Release Velocity
export function calculateReleaseVelocityScore(p: number, u: number): { deltaScore: number; successPercent: number } {
  const deltaScore = p - u;
  const successPercent = (p / (u || 1)) * 100; // prevent division by zero
  return { deltaScore, successPercent };
}

// 3. Production Quality and Reliability
export function calculateProductionQuality(
  I: number, // Total Incidents
  fixedSeverityCounts: { [severity: number]: number }, // Fixed incidents by severity
  F_I: number // Total Fixed Incidents
): number {
  let totalScore = 0;
  const severityWeights: Record<number, number> = {
    1: 0.3,
    2: 0.3,
    3: 0.2,
    4: 0.2,
  };

  for (const severity in fixedSeverityCounts) {
    const count = fixedSeverityCounts[+severity];
    const weight = severityWeights[+severity] || 0;
    totalScore += count * weight;
  }

  return (totalScore * F_I) / (I * I);
}

// 4. TPA Operational Efficiency
export function calculateEfficiencyScore(V: number, P: number): number {
  return V / P;
}

// 5. Call Center Service Level and Experience
export function calculateCallCenterScore(T: number, A: number, quality: 'Standard' | 'Gold' | 'Platinum'): number | null {
  if (T < 50) return null; // business rule: ignore if calls < 50
  const qualityWeights = {
    Standard: 0.7,
    Gold: 0.85,
    Platinum: 0.9,
  };
  return (T / A) * qualityWeights[quality];
}

// 6. Cross-Functional Program Delivery
export function calculateCrossFunctionalSuccess(T: number, E: number): number {
  return ((T - E) / T) * 100;
}

// 7. Sales Pipeline Conversion and Cycle Time
export function calculateSalesCycleConversion(T: number, B: number): number {
  return ((T - B) / T) * 100;
}

// 8. Marketing Campaign Execution Readiness
export function calculateMarketingTurnoverSuccess(IF: number, OFC: number): number {
  return 100 * ((IF / (OFC || 1)) * 10); // prevent division by zero
}

// Analytics types for dropdown selection
export const ANALYTICS_TYPES = [
  {
    id: 'engineering-delivery',
    name: 'Engineering Delivery – Predictability',
    description: 'This score measures how close a project stays to its planned timeline, adjusted for its complexity level. A score of 10 is the maximum and occurs when there is no delay (i.e., E=0), meaning perfect delivery. Scores decrease as delays increase; the minimum possible score is 0, which would mean the delay equals or exceeds the original time allocated (E ≥ T). Higher complexity projects have a bigger impact on the score when completed on time.',
    formula: 'Score = ((T - E) / T) * C',
    variables: 'T = Time in Days Assigned, E = Time in Days excess of due, C = Complexity of project (S=10, A=8, B=6, C=4, D=2)',
    scoreRange: 'Maximum: 10 (perfect delivery), Minimum: 0 (delay ≥ time allocated)',
    interpretation: 'Higher scores indicate better timeline adherence with complexity weighting'
  },
  {
    id: 'release-velocity',
    name: 'Release Velocity (Biweekly)',
    description: 'This measures how many releases were planned versus unplanned. The score can be positive (more planned than unplanned), zero (equal), or negative (more unplanned, which is undesirable). The Success Percent metric gives a ratio of planned to unplanned releases: a value of 100% means one planned for every unplanned, above 100% means better control, and below means more reactive work. The minimum is 0% (no planned releases), with no fixed upper limit.',
    formula: 'Delta Score = P - U, Success % = (P / U) * 100',
    variables: 'P = Planned releases, U = Unplanned releases',
    scoreRange: 'Delta: Positive (good), Zero (balanced), Negative (reactive). Success %: 0% minimum, no upper limit',
    interpretation: 'Positive delta and >100% success rate indicate proactive release management'
  },
  {
    id: 'production-quality',
    name: 'Production Quality and Reliability',
    description: 'This score rewards fixing severe issues and penalizes large incident volumes. The score is maximized when all incidents are resolved and of high severity, and minimized when few incidents are fixed or only minor ones are addressed. There\'s no fixed cap, but scores closer to 0.3 are indicative of higher performance with effective, timely resolution of severe incidents. A score of 0 means no incidents were fixed. There is a weightage in play meaning even if all issues are fixed, but they are minimal in importance the score would still not reach a perfect 0.3, more so towards a 0.2.',
    formula: 'Score = (Σ(Si * Ti) * Fi) / (I²)',
    variables: 'I = Total Incidents, S = Incidents by Severity, T = Severity Weight (1&2→0.3, 3&4→0.2), Fi = Fixed Incidents',
    scoreRange: 'Target: ~0.3 (high performance), Typical: ~0.2 (good), Minimum: 0 (no fixes)',
    interpretation: 'Higher scores indicate effective resolution of severe incidents with good incident management'
  },
  {
    id: 'tpa-efficiency',
    name: 'TPA Operational Efficiency and SLA Compliance',
    description: 'Efficiency is calculated by dividing output volume by number of people. The higher the score, the more productive the team is per person. The minimum score is 0 (if output is 0), and there\'s no upper limit, though practical bounds depend on workload capacity. This score helps track whether more is being done with the same or fewer resources.',
    formula: 'Score = V / P',
    variables: 'V = Output volume, P = Number of people',
    scoreRange: 'Minimum: 0 (no output), No upper limit (depends on capacity)',
    interpretation: 'Higher scores indicate better productivity per person and resource optimization'
  },
  {
    id: 'call-center',
    name: 'Call Center Service Level and Customer Experience',
    description: 'This measures the number of daily calls per agent, adjusted by a predefined quality multiplier (Standard=0.7, Gold=0.85, Platinum=0.9). The higher the call volume and quality, the higher the score. Scores are lowest when call volume is low or quality is at the lowest tier, and highest when both call volume is high and quality is Platinum. An optional threshold can limit this scoring to cases where more than 50 calls/day are handled, to emphasize sustained performance.',
    formula: 'Score = (T / A) * C',
    variables: 'T = Total Calls per day, A = Calls per agent YoY, C = Call quality (Standard=0.7, Gold=0.85, Platinum=0.9)',
    scoreRange: 'Quality multiplier: Standard (0.7), Gold (0.85), Platinum (0.9). Minimum threshold: 50 calls/day',
    interpretation: 'Higher scores indicate better call handling capacity with quality service levels'
  },
  {
    id: 'cross-functional',
    name: 'Cross Functional Program Delivery',
    description: 'This success score shows how much of a multi-team project was completed on time. A perfect score of 100% indicates no delays (T=E), while a score of 0% means a total miss or indefinitely late delivery (E ≥ T). It scales linearly based on the extent of delay. It is useful for gauging schedule alignment across teams.',
    formula: 'Score = ((T - E) / T) * 100',
    variables: 'T = Time in Days Assigned, E = Time in Days excess of due',
    scoreRange: 'Maximum: 100% (perfect on-time), Minimum: 0% (total miss or indefinite delay)',
    interpretation: 'Higher percentages indicate better cross-team coordination and schedule adherence'
  },
  {
    id: 'sales-pipeline',
    name: 'Sales Pipeline Conversion and Cycle Time',
    description: 'This score assesses how much of the product effort was preserved versus reworked (backfilled). A 100% score means there was no backfill at all (B=0), showing a highly efficient cycle. If the backfill equals the total (B=T), the score drops to 0%, implying a failed or totally recycled pipeline. The higher the score, the better the sales efficiency.',
    formula: 'Score = ((T - B) / T) * 100',
    variables: 'T = Total Product, B = Backfill amount',
    scoreRange: 'Maximum: 100% (no backfill/rework), Minimum: 0% (total rework required)',
    interpretation: 'Higher percentages indicate efficient sales processes with minimal rework'
  },
  {
    id: 'marketing-campaign',
    name: 'Marketing Campaign Execution Readiness',
    description: 'This score reflects how many initial client leads convert into signed policies. A 100% score means a 10:1 conversion ratio, i.e., one policy signed per 10 potential leads. Scores above 100% imply even better conversion (e.g., 150% means 15% of potential leads signed), while scores below 100% mean the conversion rate is worse than 10:1. The minimum score is 0 (no conversions), and there\'s no upper cap, rewarding highly successful campaigns.',
    formula: 'Score = 100 * ((IF / OFC) * 10)',
    variables: 'OFC = Initial potential clients, IF = Enforced policy signed',
    scoreRange: 'Target: 100% (10:1 conversion), Above 100% (better than 10:1), Minimum: 0% (no conversions)',
    interpretation: 'Higher scores indicate superior lead conversion rates and campaign effectiveness'
  }
];
