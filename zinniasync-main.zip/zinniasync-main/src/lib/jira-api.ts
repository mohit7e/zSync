// lib/jira-api.ts
interface JiraIssue {
  id: string;
  key: string;
  self: string;
  fields: {
    summary: string;
    status: {
      name: string;
      statusCategory: {
        name: string;
        key: string;
      };
    };
    duedate?: string;
    resolutiondate?: string;
    created: string;
    updated: string;
    project: {
      key: string;
      name: string;
      projectCategory?: {
        id: string;
        name: string;
        description: string;
      };
    };
    priority?: {
      name: string;
    };
    assignee?: {
      displayName: string;
      emailAddress: string;
    };
    [key: string]: any; // For custom fields
  };
}

interface JiraSearchResponse {
  issues: JiraIssue[];
  total: number;
  maxResults: number;
  startAt: number;
}

interface FilteredTask {
  Task_ID: string;
  Description: string;
  Planned_Date: string | null;
  Actual_Date: string | null;
  Status: string;
  Project: string; // Project key
  ProjectName: string; // Project name
  ProjectCategory: string; // Project category name
  jira_url: string; // Direct link to Jira issue
}

export class JiraApiService {
  private baseUrl: string;
  private auth: string;

  constructor(email?: string, apiToken?: string) {
    this.baseUrl = 'https://zinnia.atlassian.net';
    
    // Use environment variables for security
    const jiraEmail = email || process.env.JIRA_EMAIL;
    const jiraToken = apiToken || process.env.JIRA_API_TOKEN;
    
    if (!jiraEmail || !jiraToken) {
      throw new Error('Jira credentials not provided. Set JIRA_EMAIL and JIRA_API_TOKEN environment variables.');
    }
    
    this.auth = Buffer.from(`${jiraEmail}:${jiraToken}`).toString('base64');
  }

  private getHeaders() {
    return {
      'Authorization': `Basic ${this.auth}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
  }

  /**
   * Search for Jira issues using JQL
   */
  async searchIssues(
    jql: string = 'ORDER BY created DESC',
    maxResults: number = 100,
    startAt: number = 0
  ): Promise<JiraSearchResponse> {
    const searchBody = {
      jql,
      fields: [
        'summary',
        'status',
        'duedate',
        'resolutiondate',
        'created',
        'updated',
        'assignee',
        'priority',
        'project',
        'project.projectCategory'
      ],
      maxResults,
      startAt
    };

    try {
      const response = await fetch(`${this.baseUrl}/rest/api/3/search`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify(searchBody)
      });

      if (!response.ok) {
        throw new Error(`Jira API Error: ${response.status} ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to fetch Jira issues:', error);
      throw error;
    }
  }

  /**
   * Get tasks filtered for the specific fields you need
   */
  async getFilteredTasks(
    projectKey?: string,
    statusCategory?: string,
    maxResults: number = 100
  ): Promise<FilteredTask[]> {
    let jql = 'ORDER BY created DESC';
    
    // Build JQL query based on filters
    const conditions: string[] = [];
    
    if (projectKey) {
      conditions.push(`project = "${projectKey}"`);
    }
    
    if (statusCategory) {
      conditions.push(`statusCategory = "${statusCategory}"`);
    }
    
    if (conditions.length > 0) {
      jql = `${conditions.join(' AND ')} ORDER BY created DESC`;
    }

    const response = await this.searchIssues(jql, maxResults);
    
    return response.issues.map(issue => ({
      Task_ID: issue.key,
      Description: issue.fields.summary,
      Planned_Date: issue.fields.duedate || null,
      Actual_Date: issue.fields.resolutiondate || null,
      Status: issue.fields.status.name,
      Project: issue.fields.project.key,
      ProjectName: issue.fields.project.name,
      ProjectCategory: issue.fields.project.projectCategory?.name || '',
      jira_url: `${this.baseUrl}/browse/${issue.key}`
    }));
  }

  /**
   * Get tasks by specific JQL query
   */
  async getTasksByJQL(jql: string): Promise<FilteredTask[]> {
    const response = await this.searchIssues(jql);
    
    return response.issues.map(issue => ({
      Task_ID: issue.key,
      Description: issue.fields.summary,
      Planned_Date: issue.fields.duedate || null,
      Actual_Date: issue.fields.resolutiondate || null,
      Status: issue.fields.status.name,
      Project: issue.fields.project.key,
      ProjectName: issue.fields.project.name,
      ProjectCategory: issue.fields.project.projectCategory?.name || '',
      jira_url: `${this.baseUrl}/browse/${issue.key}`
    }));
  }

  /**
   * Get tasks for a specific date range
   */
  async getTasksByDateRange(
    startDate: string,
    endDate: string,
    projectKey?: string
  ): Promise<FilteredTask[]> {
    let jql = `created >= "${startDate}" AND created <= "${endDate}"`;
    
    if (projectKey) {
      jql = `project = "${projectKey}" AND ${jql}`;
    }
    
    jql += ' ORDER BY created DESC';
    
    return this.getTasksByJQL(jql);
  }

  /**
   * Get ALL tasks using pagination (fetches everything)
   */
  async getAllTasks(
    projectKey?: string,
    statusCategory?: string,
    customJql?: string
  ): Promise<FilteredTask[]> {
    let jql = customJql || 'ORDER BY created DESC';
    
    if (!customJql) {
      // Build JQL query based on filters
      const conditions: string[] = [];
      
      if (projectKey) {
        conditions.push(`project = "${projectKey}"`);
      }
      
      if (statusCategory) {
        conditions.push(`statusCategory = "${statusCategory}"`);
      }
      
      if (conditions.length > 0) {
        jql = `${conditions.join(' AND ')} ORDER BY created DESC`;
      }
    }

    const allTasks: FilteredTask[] = [];
    let startAt = 0;
    const maxResults = 100; // Jira's recommended batch size
    let totalFetched = 0;
    const maxTotal = 5000; // Safety limit to prevent infinite loops

    while (totalFetched < maxTotal) {
      const response = await this.searchIssues(jql, maxResults, startAt);
      
      const batchTasks = response.issues.map(issue => ({
        Task_ID: issue.key,
        Description: issue.fields.summary,
        Planned_Date: issue.fields.duedate || null,
        Actual_Date: issue.fields.resolutiondate || null,
        Status: issue.fields.status.name,
        Project: issue.fields.project.key,
        ProjectName: issue.fields.project.name,
        ProjectCategory: issue.fields.project.projectCategory?.name || '',
        jira_url: `${this.baseUrl}/browse/${issue.key}`
      }));
      
      allTasks.push(...batchTasks);
      totalFetched += batchTasks.length;
      
      // If we got fewer results than requested, we've reached the end
      if (batchTasks.length < maxResults) {
        break;
      }
      
      // Update startAt for next batch
      startAt += maxResults;
    }

    return allTasks;
  }
}

// Usage examples and helper functions
export const jiraQueries = {
  // Get all tasks from a specific project
  byProject: (projectKey: string) => `project = "${projectKey}" ORDER BY created DESC`,
  
  // Get completed tasks
  completed: () => 'statusCategory = "Done" ORDER BY resolutiondate DESC',
  
  // Get in-progress tasks
  inProgress: () => 'statusCategory = "In Progress" ORDER BY updated DESC',
  
  // Get overdue tasks (past due date)
  overdue: () => 'duedate < now() AND statusCategory != "Done" ORDER BY duedate ASC',
  
  // Get tasks by assignee
  byAssignee: (email: string) => `assignee = "${email}" ORDER BY created DESC`,
  
  // Get tasks created in last N days
  recentTasks: (days: number) => `created >= -${days}d ORDER BY created DESC`
};

export default JiraApiService;
