'use client'

import { useState } from 'react'
import { useDropzone } from 'react-dropzone'
import { useQuery, useMutation } from '@tanstack/react-query'
import Papa from 'papaparse'
import { toast } from 'sonner'
import { Upload, FileSpreadsheet, AlertCircle } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'

interface ParsedData {
  data: any[]
  headers: string[]
}

export default function UploadPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('')
  const [parsedData, setParsedData] = useState<ParsedData | null>(null)
  const [isUploading, setIsUploading] = useState(false)

  // Fetch categories
  const { data: categories = [], isLoading: categoriesLoading } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const response = await fetch('/api/categories')
      if (!response.ok) throw new Error('Failed to fetch categories')
      return response.json()
    }
  })

  // Upload mutation
  const uploadMutation = useMutation({
    mutationFn: async (data: { csvData: any[], categoryId: string, categoryName: string }) => {
      const response = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
      if (!response.ok) throw new Error('Upload failed')
      return response.json()
    },
    onSuccess: (data) => {
      toast.success(data.message || 'Upload successful')
      setParsedData(null)
      setSelectedCategory('')
    },
    onError: (error) => {
      toast.error('Upload failed: ' + error.message)
    }
  })

  const onDrop = (acceptedFiles: File[]) => {
    const file = acceptedFiles[0]
    if (!file) return

    Papa.parse(file, {
      header: true,
      complete: (results) => {
        if (results.data && results.data.length > 0) {
          setParsedData({
            data: results.data as any[],
            headers: Object.keys(results.data[0] as any)
          })
        }
      },
      error: (error) => {
        toast.error('Failed to parse CSV: ' + error.message)
      }
    })
  }

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.ms-excel': ['.csv'],
      'text/plain': ['.csv']
    },
    multiple: false
  })

  const handleUpload = async () => {
    if (!parsedData || !selectedCategory) {
      toast.error('Please select a category and upload a CSV file')
      return
    }

    const category = categories.find((c: any) => c.id === selectedCategory)
    if (!category) return

    setIsUploading(true)
    await uploadMutation.mutateAsync({
      csvData: parsedData.data,
      categoryId: selectedCategory,
      categoryName: category.name
    })
    setIsUploading(false)
  }

  return (
    <div className="container mx-auto py-8 px-4 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Upload Metrics</h1>
        <p className="text-muted-foreground mt-2">
          Upload CSV files containing execution metrics to automatically tag and categorize them
        </p>
      </div>

      <div className="grid gap-6">
        {/* Category Selection */}
        <Card>
          <CardHeader>
            <CardTitle>Select Category</CardTitle>
            <CardDescription>Choose the metric category for your CSV file</CardDescription>
          </CardHeader>
          <CardContent>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full max-w-md">
                <SelectValue placeholder="Select a category..." />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category: any) => (
                  <SelectItem key={category.id} value={category.id}>
                    <div>
                      <div className="font-medium">{category.name}</div>
                      {category.description && (
                        <div className="text-sm text-muted-foreground">{category.description}</div>
                      )}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* File Upload */}
        <Card>
          <CardHeader>
            <CardTitle>Upload CSV File</CardTitle>
            <CardDescription>Drag and drop your CSV file or click to browse</CardDescription>
          </CardHeader>
          <CardContent>
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors
                ${isDragActive ? 'border-primary bg-primary/5' : 'border-muted-foreground/25 hover:border-primary/50'}`}
            >
              <input {...getInputProps()} />
              <FileSpreadsheet className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              {isDragActive ? (
                <p className="text-lg">Drop the CSV file here...</p>
              ) : (
                <div>
                  <p className="text-lg mb-2">Drag & drop a CSV file here, or click to select</p>
                  <p className="text-sm text-muted-foreground">Supported formats: .csv</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Data Preview */}
        {parsedData && (
          <Card>
            <CardHeader>
              <CardTitle>Data Preview</CardTitle>
              <CardDescription>
                Showing first 5 rows of {parsedData.data.length} total rows
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      {parsedData.headers.map((header) => (
                        <TableHead key={header} className="min-w-[100px]">
                          {header}
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {parsedData.data.slice(0, 5).map((row: any, idx) => (
                      <TableRow key={idx}>
                        {parsedData.headers.map((header) => (
                          <TableCell key={header}>
                            {row[header] || '-'}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">
                    Data will be automatically tagged based on planned and actual dates
                  </p>
                </div>
                <Button
                  onClick={handleUpload}
                  disabled={!selectedCategory || isUploading}
                  className="min-w-[120px]"
                >
                  {isUploading ? (
                    <>
                      <Upload className="mr-2 h-4 w-4 animate-pulse" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Upload Data
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* CSV Format Guide */}
        <Card>
          <CardHeader>
            <CardTitle>CSV Format Guide</CardTitle>
            <CardDescription>Expected fields for each category type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <h4 className="font-medium mb-2">Engineering</h4>
                <div className="text-sm text-muted-foreground space-y-1">
                  <p>• Task_ID, Description, Planned_Date, Actual_Date</p>
                  <p>• Complexity, Time_Duration_T_days, Status</p>
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-2">Call Center</h4>
                <div className="text-sm text-muted-foreground space-y-1">
                  <p>• Agent_ID, Target_Date, Achievement_Date</p>
                  <p>• Total_Calls_T, Call_Quality_Type, Quality_Value_C</p>
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-2">Production</h4>
                <div className="text-sm text-muted-foreground space-y-1">
                  <p>• Incident_ID, Description, Target_Date, Resolution_Date</p>
                  <p>• Severity, Total_Incidents_I, Sev1-4_Incidents</p>
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-2">Other Categories</h4>
                <div className="text-sm text-muted-foreground space-y-1">
                  <p>• Generic format with ID, Description</p>
                  <p>• Planned/Target date and Actual/Completion date</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
} 