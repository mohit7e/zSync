-- CreateTable
CREATE TABLE "analytics_data" (
    "id" TEXT NOT NULL,
    "business_type" TEXT NOT NULL,
    "row_index" INTEGER NOT NULL,
    "data" JSONB NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "analytics_data_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "analytics_data_business_type_idx" ON "analytics_data"("business_type");
