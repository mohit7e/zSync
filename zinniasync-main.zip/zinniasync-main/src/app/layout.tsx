import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import QueryProvider from '@/providers/query-provider'
import { Toaster } from '@/components/ui/sonner'
import { Navigation } from '@/components/navigation'
import { ThemeProvider } from '@/context/theme-context'
import { FloatingUploadButton } from '@/components/floating-upload-button'

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "zSync - Execution Metrics Automation",
  description: "Automated collection and tagging of execution metrics from multiple data sources",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${inter.className} antialiased`}>
        <ThemeProvider>
          <QueryProvider>
            <Navigation />
            <main className="min-h-screen bg-background">
              {children}
            </main>
            <FloatingUploadButton />
            <Toaster />
          </QueryProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
