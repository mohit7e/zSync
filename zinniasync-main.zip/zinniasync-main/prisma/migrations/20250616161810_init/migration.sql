-- CreateTable
CREATE TABLE "metric_categories" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "metric_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "metrics" (
    "id" TEXT NOT NULL,
    "source" TEXT NOT NULL,
    "metric_type" TEXT NOT NULL,
    "task_id" TEXT,
    "description" TEXT NOT NULL,
    "planned_date" TIMESTAMP(3) NOT NULL,
    "actual_date" TIMESTAMP(3),
    "status" TEXT NOT NULL,
    "tag" TEXT NOT NULL,
    "category_id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "value" DOUBLE PRECISION,
    "target" DOUBLE PRECISION,
    "unit" TEXT,
    "metadata" JSONB,

    CONSTRAINT "metrics_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "metric_categories_name_key" ON "metric_categories"("name");

-- CreateIndex
CREATE INDEX "metrics_category_id_idx" ON "metrics"("category_id");

-- CreateIndex
CREATE INDEX "metrics_tag_idx" ON "metrics"("tag");

-- CreateIndex
CREATE INDEX "metrics_status_idx" ON "metrics"("status");

-- CreateIndex
CREATE INDEX "metrics_planned_date_idx" ON "metrics"("planned_date");

-- AddForeignKey
ALTER TABLE "metrics" ADD CONSTRAINT "metrics_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "metric_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
