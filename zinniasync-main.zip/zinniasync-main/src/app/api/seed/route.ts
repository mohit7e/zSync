import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    console.log('🌱 Starting database seeding...')
    
    // Create metric categories
    const categories = [
      { name: 'Engineering', description: 'Engineering delivery and technical metrics' },
      { name: 'Release', description: 'Release velocity and deployment metrics' },
      { name: 'Production', description: 'Production quality and incident metrics' },
      { name: 'TPA', description: 'Third-party application operational metrics' },
      { name: 'Call Center', description: 'Call center service and efficiency metrics' },
      { name: 'Cross-Functional', description: 'Cross-functional program and project metrics' },
      { name: 'Sales', description: 'Sales pipeline and conversion metrics' },
      { name: 'Marketing', description: 'Marketing campaign and delivery metrics' },
    ]

    // Clear existing data
    await prisma.metric.deleteMany({})
    await prisma.metricCategory.deleteMany({})
    console.log('🧹 Cleared existing data')

    // Create categories
    const createdCategories: { [key: string]: any } = {}
    for (const category of categories) {
      const created = await prisma.metricCategory.create({ data: category })
      createdCategories[category.name] = created
    }
    console.log('✅ Metric categories seeded successfully')

    // Helper function to generate dates
    const getRandomDate = (daysAgo: number, variance: number = 5) => {
      const baseDate = new Date()
      baseDate.setDate(baseDate.getDate() - daysAgo)
      const randomOffset = Math.floor(Math.random() * variance * 2) - variance
      baseDate.setDate(baseDate.getDate() + randomOffset)
      return baseDate
    }

    // Sample metrics data
    const sampleMetrics = [
      // Engineering metrics
      {
        source: 'JIRA',
        metricType: 'Feature Delivery',
        taskId: 'ENG-001',
        description: 'User authentication system',
        plannedDate: getRandomDate(30),
        actualDate: getRandomDate(29),
        status: 'Completed',
        tag: 'on-time',
        categoryId: createdCategories['Engineering'].id,
        value: 85,
        unit: 'completion %'
      },
      {
        source: 'JIRA',
        metricType: 'Feature Delivery',
        taskId: 'ENG-002',
        description: 'Payment gateway integration',
        plannedDate: getRandomDate(25),
        actualDate: getRandomDate(22),
        status: 'Completed',
        tag: 'delayed',
        categoryId: createdCategories['Engineering'].id,
        value: 78,
        unit: 'completion %'
      },
      {
        source: 'JIRA',
        metricType: 'Feature Delivery',
        taskId: 'ENG-003',
        description: 'Mobile app optimization',
        plannedDate: getRandomDate(20),
        actualDate: getRandomDate(18),
        status: 'Completed',
        tag: 'on-time',
        categoryId: createdCategories['Engineering'].id,
        value: 92,
        unit: 'completion %'
      },
      // Release metrics
      {
        source: 'Jenkins',
        metricType: 'Release Deployment',
        taskId: 'REL-001',
        description: 'Q4 2024 Release v2.1.0',
        plannedDate: getRandomDate(35),
        actualDate: getRandomDate(34),
        status: 'Completed',
        tag: 'on-time',
        categoryId: createdCategories['Release'].id,
        value: 95,
        unit: 'velocity score'
      },
      {
        source: 'Jenkins',
        metricType: 'Release Deployment',
        taskId: 'REL-002',
        description: 'Hotfix v2.1.1',
        plannedDate: getRandomDate(28),
        actualDate: getRandomDate(30),
        status: 'Completed',
        tag: 'delayed',
        categoryId: createdCategories['Release'].id,
        value: 82,
        unit: 'velocity score'
      },
      // Production metrics
      {
        source: 'Monitoring',
        metricType: 'Incident Response',
        taskId: 'PROD-001',
        description: 'Database performance issue',
        plannedDate: getRandomDate(20),
        actualDate: getRandomDate(18),
        status: 'Resolved',
        tag: 'on-time',
        categoryId: createdCategories['Production'].id,
        value: 92,
        unit: 'quality score'
      },
      {
        source: 'Monitoring',
        metricType: 'Incident Response',
        taskId: 'PROD-002',
        description: 'API timeout issues',
        plannedDate: getRandomDate(15),
        actualDate: getRandomDate(17),
        status: 'Resolved',
        tag: 'delayed',
        categoryId: createdCategories['Production'].id,
        value: 76,
        unit: 'quality score'
      },
      // TPA metrics
      {
        source: 'TPA System',
        metricType: 'Operational Efficiency',
        taskId: 'TPA-001',
        description: 'Payment processor integration',
        plannedDate: getRandomDate(40),
        actualDate: getRandomDate(38),
        status: 'Operational',
        tag: 'on-time',
        categoryId: createdCategories['TPA'].id,
        value: 88,
        unit: 'efficiency %'
      },
      // Call Center metrics
      {
        source: 'Call Center',
        metricType: 'Service Level',
        taskId: 'CC-001',
        description: 'Customer support Q4 metrics',
        plannedDate: getRandomDate(30),
        actualDate: getRandomDate(29),
        status: 'Completed',
        tag: 'on-time',
        categoryId: createdCategories['Call Center'].id,
        value: 94,
        unit: 'service level %'
      },
      // Cross-Functional metrics
      {
        source: 'Project Management',
        metricType: 'Program Delivery',
        taskId: 'CF-001',
        description: 'Q4 cross-team initiative',
        plannedDate: getRandomDate(50),
        actualDate: getRandomDate(48),
        status: 'Completed',
        tag: 'on-time',
        categoryId: createdCategories['Cross-Functional'].id,
        value: 88,
        unit: 'delivery score'
      },
      // Sales metrics
      {
        source: 'CRM',
        metricType: 'Pipeline Conversion',
        taskId: 'SALES-001',
        description: 'Enterprise client acquisition Q4',
        plannedDate: getRandomDate(45),
        actualDate: getRandomDate(43),
        status: 'Closed Won',
        tag: 'on-time',
        categoryId: createdCategories['Sales'].id,
        value: 89,
        unit: 'conversion %'
      },
      {
        source: 'CRM',
        metricType: 'Pipeline Conversion',
        taskId: 'SALES-002',
        description: 'SMB market expansion',
        plannedDate: getRandomDate(38),
        actualDate: getRandomDate(41),
        status: 'Closed Won',
        tag: 'delayed',
        categoryId: createdCategories['Sales'].id,
        value: 73,
        unit: 'conversion %'
      },
      // Marketing metrics
      {
        source: 'Marketing Automation',
        metricType: 'Campaign Execution',
        taskId: 'MKT-001',
        description: 'Q4 Product launch campaign',
        plannedDate: getRandomDate(42),
        actualDate: getRandomDate(41),
        status: 'Completed',
        tag: 'on-time',
        categoryId: createdCategories['Marketing'].id,
        value: 91,
        unit: 'execution score'
      },
      {
        source: 'Marketing Automation',
        metricType: 'Campaign Execution',
        taskId: 'MKT-002',
        description: 'Holiday season promotion',
        plannedDate: getRandomDate(35),
        actualDate: getRandomDate(38),
        status: 'Completed',
        tag: 'delayed',
        categoryId: createdCategories['Marketing'].id,
        value: 78,
        unit: 'execution score'
      }
    ]

    // Create all metrics
    for (const metric of sampleMetrics) {
      await prisma.metric.create({ data: metric })
    }

    console.log('✅ Sample metrics created successfully')
    console.log(`📊 Created ${sampleMetrics.length} metrics across ${categories.length} categories`)

    return NextResponse.json({
      success: true,
      message: 'Database seeded successfully',
      data: {
        categoriesCreated: categories.length,
        metricsCreated: sampleMetrics.length
      }
    })

  } catch (error) {
    console.error('Seeding error:', error)
    return NextResponse.json(
      { error: 'Failed to seed database', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
