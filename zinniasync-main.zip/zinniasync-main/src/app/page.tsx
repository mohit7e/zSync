import Link from 'next/link'
import { ArrowRight, Upload, BarChart3, Zap, Target, Clock, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export default function HomePage() {
  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      {/* Hero Section */}
      <div className="text-center mb-12 md:mb-16">
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 leading-tight">
          zSync - Execution Metrics Automation
        </h1>
        <p className="text-lg md:text-xl text-muted-foreground mb-6 md:mb-8 max-w-2xl mx-auto px-2">
          Automate the collection and tagging of execution metrics from multiple data sources. 
          Track performance across all your OKR categories with intelligent tagging.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center items-center">
          <Link href="/dashboard" className="w-full sm:w-auto">
            <Button size="lg" className="gap-2 w-full sm:w-auto">
              <BarChart3 className="h-5 w-5" />
              View Dashboard
            </Button>
          </Link>
        </div>
      </div>

      {/* Features Grid */}
      <div className="mb-12 md:mb-16">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 md:mb-12">Key Features</h2>
        <div className="grid gap-4 md:gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <Zap className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Automated Tagging</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Automatically classify deliverables as on-time, delayed, incomplete, 
                or in-progress based on intelligent date comparison logic.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Target className="h-10 w-10 text-primary mb-2" />
              <CardTitle>OKR Alignment</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Track metrics across 8 execution OKR categories including Engineering, 
                Release, Production, TPA, Call Center, Cross-Functional, Sales, and Marketing.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <BarChart3 className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Real-time Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Visualize your metrics with interactive charts, monitor on-time delivery 
                rates, and identify areas needing attention at a glance.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Upload className="h-10 w-10 text-primary mb-2" />
              <CardTitle>CSV Import</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Simple drag-and-drop interface for uploading CSV files. 
                Supports multiple formats with intelligent field mapping.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Clock className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Performance Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Monitor key metrics like On-Time Delivery Rate with configurable 
                targets. Export data for further analysis.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Shield className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Data Integrity</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Preview data before import, validate formats, and ensure accurate 
                metric classification with our robust parsing engine.
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* How It Works Section */}
      <div className="mb-12 md:mb-16">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 md:mb-12">How It Works</h2>
        <div className="max-w-4xl mx-auto">
          <div className="space-y-6 md:space-y-8">
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              zSync transforms complex execution data into actionable insights through our intelligent 4-step process
            </p>
          </div>
          
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2">
            {/* Step 1: Data Upload */}
            <div className="bg-card border border-border rounded-xl p-4 md:p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start gap-3 md:gap-4">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 border border-primary/20">
                  <span className="text-lg md:text-xl font-bold text-primary">1</span>
                </div>
                <div>
                  <h3 className="text-lg md:text-xl font-semibold mb-2 md:mb-3 text-foreground">Upload Your Data</h3>
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    Simply drag and drop your CSV files containing execution data. The system supports multiple formats and automatically maps fields for <strong className="text-foreground">8 different OKR categories</strong>: Engineering Delivery, Release Velocity, Production Quality, TPA Operations, Call Center Service, Cross-Functional Programs, Sales Pipeline, and Marketing Campaigns.
                  </p>
                </div>
              </div>
            </div>

            {/* Step 2: Data Processing */}
            <div className="bg-card border border-border rounded-xl p-4 md:p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start gap-3 md:gap-4">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 border border-primary/20">
                  <span className="text-lg md:text-xl font-bold text-primary">2</span>
                </div>
                <div>
                  <h3 className="text-lg md:text-xl font-semibold mb-2 md:mb-3 text-foreground">Smart Data Processing</h3>
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    All incoming data is stored and processed to generate <strong className="text-foreground">real-time progress scores</strong>. Using 42 input metrics, the system distills them into <strong className="text-foreground"> 8 simplified scores</strong>, displayed clearly on the Analytics Dashboard.
                  </p>
                </div>
              </div>
            </div>

            {/* Step 3: Analytics Dashboard */}
            <div className="bg-card border border-border rounded-xl p-4 md:p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start gap-3 md:gap-4">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 border border-primary/20">
                  <span className="text-lg md:text-xl font-bold text-primary">3</span>
                </div>
                <div>
                  <h3 className="text-lg md:text-xl font-semibold mb-2 md:mb-3 text-foreground">Detailed Analytics Insights</h3>
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    The Detailed Analytics page breaks down each of the <strong className="text-foreground">8 OKR scores</strong>, explaining their meaning and guiding improvement areas. Users can click into any score for deeper insights.
                  </p>
                </div>
              </div>
            </div>

            {/* Step 4: Projects Hub */}
            <div className="bg-card border border-border rounded-xl p-4 md:p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start gap-3 md:gap-4">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 border border-primary/20">
                  <span className="text-lg md:text-xl font-bold text-primary">4</span>
                </div>
                <div>
                  <h3 className="text-lg md:text-xl font-semibold mb-2 md:mb-3 text-foreground">Projects Hub Integration</h3>
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    The <strong className="text-foreground">Projects tab</strong> surfaces active tasks via JIRA links for real-time updates. While not used in scoring, it complements analytics by acting as a <strong className="text-foreground">central hub</strong> for Zinnia's execution visibility.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Visual Flow Indicator */}
          <div className="mt-8 md:mt-12 text-center">
            <div className="inline-flex flex-wrap items-center justify-center gap-2 md:gap-3 bg-muted/30 rounded-full px-4 md:px-8 py-3 md:py-4 border border-border/50">
              <div className="flex items-center gap-1 md:gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span className="text-xs font-medium text-muted-foreground">Ingest</span>
              </div>
              <div className="w-3 md:w-6 h-px bg-gradient-to-r from-primary/50 to-primary/30"></div>
              <div className="flex items-center gap-1 md:gap-2">
                <div className="w-2 h-2 bg-primary/80 rounded-full"></div>
                <span className="text-xs font-medium text-muted-foreground">Process</span>
              </div>
              <div className="w-3 md:w-6 h-px bg-gradient-to-r from-primary/30 to-primary/50"></div>
              <div className="flex items-center gap-1 md:gap-2">
                <div className="w-2 h-2 bg-primary/60 rounded-full"></div>
                <span className="text-xs font-medium text-muted-foreground">Analyze</span>
              </div>
              <div className="w-3 md:w-6 h-px bg-gradient-to-r from-primary/50 to-primary/30"></div>
              <div className="flex items-center gap-1 md:gap-2">
                <div className="w-2 h-2 bg-primary/40 rounded-full"></div>
                <span className="text-xs font-medium text-muted-foreground">Manage</span>
              </div>
            </div>
            <p className="text-xs md:text-sm text-muted-foreground mt-3 md:mt-4 px-4">Seamless workflow from data ingestion to actionable insights</p>
          </div>
        </div>
      </div>
    </div>
  )
}
